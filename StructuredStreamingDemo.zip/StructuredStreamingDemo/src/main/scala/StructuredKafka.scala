import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
/**
 * 使用 StructedStreaming读取kafka中的数据 */

object StructuredKafka {
  def main(args: Array[String]): Unit = {
    //1 获取sparksession
    val spark: SparkSession =
      SparkSession.builder()
        .master("local[*]")
        .appName(StructuredKafka.getClass.getName)
        .getOrCreate()
    spark.sparkContext.setLogLevel("WARN")
    import spark.implicits._

    //2 定义读取kafka数据源
    val kafkaDf: DataFrame = spark.readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", "hadoop4:9092")
      .option("subscribe", "spark_kafka")
      .load()

    //3 处理数据
    // ●注意:读取后的数据的Schema是固定的，包含的列如下（可参考下课件）
    val kafkaValDf: DataFrame = kafkaDf.selectExpr("CAST(value AS STRING)")

    //转为ds
    val kafkaDs: Dataset[String] = kafkaValDf.as[String]
    val kafkaWordDs: Dataset[String] = kafkaDs.flatMap(_.split(" "))

    //执行聚合
    val res: Dataset[Row] = kafkaWordDs.groupBy("value").count().sort($"count".desc)
    //4 输出
    res.writeStream
      .format("console")
      .outputMode("complete")
      .start()
      .awaitTermination()
  }
}