package com.lg.kafka

import com.lg.domain.BusInfo
import org.apache.spark.sql.{Column, DataFrame, Dataset, SparkSession}

class StructedKafka3 {
  def main(args: Array[String]): Unit = {
    //1 获取sparksession
    val spark: SparkSession = SparkSession.builder()
      .master("local[*]")
      .appName("kafka-redis")
      .getOrCreate()
    val sc = spark.sparkContext
    sc.setLogLevel("WARN")
    import spark.implicits._

    //2 定义读取kafka数据源
    val kafkaDf: DataFrame = spark.readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", "hadoop4:9092")
      .option("subscribe", "lagou_bus_info")
      .load()

    //3 处理数据
    val kafkaValDf: DataFrame = kafkaDf.selectExpr("CAST(value AS STRING)")
    //转为ds
    val kafkaDs: Dataset[String] = kafkaValDf.as[String]
    val busInfoDs: Dataset[BusInfo] = kafkaDs.map(msg => {BusInfo(msg)})
    val warnInfoDS = busInfoDs.filter(info => {
      val remain: String = info.oilRemain
      remain.toInt < 30
    })

    // 写入到Kafka的另外一个主题
    warnInfoDS.withColumn("value", new Column("deployNum"))
      .writeStream
      .format("kafka")
      .option("kafka.bootstrap.servers", "hadoop2:9092,hadoop3:9092,hadoop4:9092")
      .option("topic", "lagou_bus_warn_info")
      .option("checkpointLocation", "./ssc")
      .start()
      .awaitTermination()
  }
}
