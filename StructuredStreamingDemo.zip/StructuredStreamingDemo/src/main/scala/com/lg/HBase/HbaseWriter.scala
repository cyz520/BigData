package com.lg.HBase

import com.lg.domain.BusInfo
import org.apache.hadoop.hbase.{HBaseConfiguration, TableName}
import org.apache.hadoop.hbase.client.{Connection, ConnectionFactory, Put, Table}
import org.apache.hadoop.hbase.util.Bytes
import org.apache.spark.sql.ForeachWriter

object HbaseWriter {
  // hbase的Connection底层已经使用了线程池，而且Connection是线程安全的，可以全局使用一个
  // 但是对于table、admin需要每个线程使用一个
  var connect: Connection = _

  def getHbaseTable() = {
      if (connect != null) {
        val table = connect.getTable(TableName.valueOf("htb_gps"))
        table
      } else {
        val conf = HBaseConfiguration.create
        conf.set("hbase.zookeeper.property.clientPort", "2181")
        conf.set("hbase.zookeeper.quorum", "hadoop3,hadoop4")
        connect = ConnectionFactory.createConnection(conf)
        val table = connect.getTable(TableName.valueOf("htb_gps"))
        table
      }
  }
}

class HbaseWriter extends ForeachWriter[BusInfo] {
  var table: Table = _

  override def open(partitionId: Long, epochId: Long): Boolean = {
    table = HbaseWriter.getHbaseTable()
    true
  }

  override def process(info: BusInfo): Unit = {
    //Rowkey:行程唯一编号+车牌编号+timestamp
    //列族:car_info
    //列:数据的全部字段
    val rowkey = info.deployNum + info.plateNum + info.timeStr
    val put = new Put(Bytes.toBytes(rowkey))
    val lglat: String = info.lglat
    val arr: Array[String] = lglat.split("_")

    put.addColumn(
      Bytes.toBytes("car_info"),
      Bytes.toBytes("lng"),
      Bytes.toBytes(arr(0)))

    put.addColumn(
      Bytes.toBytes("car_info"),
      Bytes.toBytes("lat"),
      Bytes.toBytes(arr(1)))

    table.put(put)
  }

  override def close(errorOrNull: Throwable): Unit = {
    table.close()
  }
}
