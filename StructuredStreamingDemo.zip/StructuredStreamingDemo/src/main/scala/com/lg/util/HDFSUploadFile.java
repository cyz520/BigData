package com.lg.util;


import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.io.IOUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URI;


public class HDFSUploadFile {
    public static FileSystem hdfs;

    /**
     *
     * @param srcPath :上传的本地路径
     * @param dstPath：上传的hdfs路径
     * @throws Exception
     */
    public static void uploadFile(String srcPath, String dstPath) throws Exception {
        Path src=new Path(srcPath);
        Path dest=new Path(dstPath);
        hdfs.copyFromLocalFile(src,dest);


    }

    /**
     *
     * @param srcPath:上传的本地文件夹路径
     * @param dstPath：上传的hdfs文件夹路径
     * @throws Exception
     */
    public static void uploadFolder(String srcPath, String dstPath) throws Exception {

        init("hdfs://lgns");
        File dir = new File(srcPath);
        File[] files = dir.listFiles();

        Path dest=new Path(dstPath);
        final boolean exists = hdfs.exists(dest);
        if(!exists){ hdfs.mkdirs(dest);};

        for (File file : files) {
            String srcFile = file.getAbsolutePath().toString();
            int fileNamePosi = srcFile.lastIndexOf('\\');
            String fileName = srcFile.substring(fileNamePosi + 1);//获取到文件名
            //上传hdfs文件系统
            upload(srcFile, dstPath + '/' + fileName);
        }

    }

    public static void init(String ns) throws IOException, InterruptedException {
        Configuration conf = new Configuration();
        conf.set("dfs.client.use.datanode.hostname", "true");
        hdfs = FileSystem.get(URI.create(ns), conf, "root");
    }

    public static void destory() {
        try {
            hdfs.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void upload(String srcPath, String dstPath) throws Exception {

        if (new File(srcPath).isFile()) {
            uploadFile(srcPath, dstPath);
        } else {
            uploadFolder(srcPath, dstPath);
        }
    }

    public static void main(String[] args) throws Exception {

        Configuration conf = new Configuration();
        conf.set("dfs.client.use.datanode.hostname", "true");
        hdfs = FileSystem.get(URI.create("hdfs://lgns"), conf, "root");
        upload("e://replenishment", "/replenishment");

    }

}