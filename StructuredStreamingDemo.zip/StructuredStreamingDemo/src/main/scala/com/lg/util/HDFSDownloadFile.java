package com.lg.util;


import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.io.IOUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URI;


public class HDFSDownloadFile {
    public static FileSystem hdfs;

    public static void downloadFile(String srcPath, String dstPath) throws Exception {
        FSDataInputStream in = null;
        FileOutputStream out = null;
        try {
            in = hdfs.open(new Path(srcPath));
            out = new FileOutputStream(dstPath);
            IOUtils.copyBytes(in, out, 4096, false);
        } finally {
            IOUtils.closeStream(in);
            IOUtils.closeStream(out);
        }
    }

    public static void downloadFolder(String srcPath, String dstPath) throws Exception {
        File dstDir = new File(dstPath);
        if (!dstDir.exists()) {
            dstDir.mkdirs();
        }
        FileStatus[] srcFileStatus = hdfs.listStatus(new Path(srcPath));
        Path[] srcFilePath = FileUtil.stat2Paths(srcFileStatus);
        for (int i = 0; i < srcFilePath.length; i++) {
            String srcFile = srcFilePath[i].toString();
            int fileNamePosi = srcFile.lastIndexOf('/');
            String fileName = srcFile.substring(fileNamePosi + 1);
            download(srcPath + '/' + fileName, dstPath + '/' + fileName);
        }
    }

    public static void init(String ns) throws IOException, InterruptedException {
        Configuration conf = new Configuration();
        conf.set("dfs.client.use.datanode.hostname", "true");
        hdfs = FileSystem.get(URI.create(ns), conf, "root");
    }

    public static void destory() {
        try {
            hdfs.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void download(String srcPath, String dstPath) throws Exception {
        init("hdfs://lgns");
        if (hdfs.isFile(new Path(srcPath))) {
            downloadFile(srcPath, dstPath);
        } else {
            downloadFolder(srcPath, dstPath);
        }
        destory();
    }

    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("Invalid input parameters");
        } else {
            try {
                Configuration conf = new Configuration();
                conf.set("dfs.client.use.datanode.hostname", "true");
                hdfs = FileSystem.get(URI.create("hdfs://lgns"), conf, "root");
                download(args[0], args[1]);
            } catch (Exception e) {
                System.out.println("Error occured when copy files");
            }
        }
    }
}