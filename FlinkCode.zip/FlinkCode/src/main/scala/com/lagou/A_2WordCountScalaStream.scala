package com.lagou

import org.apache.flink.streaming.api.scala._

/**
 * 输入：hello        输出 (hello, 1)
 * 输入：you him she  输出 (you, 1) (him, 1) (she, 1)
 * 输入：hello        输出 (hello, 2)
 * 输入：hello        输出 (hello, 3) --- 不会把之前的记录数给丢弃
 * */
object A_2WordCountScalaStream {
  def main(args: Array[String]): Unit = {
    // 处理流式数据
    val environment: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    val streamData: DataStream[String] = environment.socketTextStream("192.168.11.53", 7777)

    val out: DataStream[(String, Int)] = streamData
      .flatMap(_.split("\\s+"))
      .map((_, 1))
      .keyBy(0)
      .sum(1)

    out.print()

    environment.execute()
  }
}
