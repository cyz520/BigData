package com.lagou

import org.apache.flink.api.scala._

object A_1WordCountScalaBatch {
  def main(args: Array[String]): Unit = {
    val inPath = "/Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/7-第六阶段/FlinkCode/src/main/resources/hello.txt";
    val outPath = "/Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/7-第六阶段/FlinkCode/src/main/resources/output";
    val environment: ExecutionEnvironment = ExecutionEnvironment.getExecutionEnvironment

    val text: DataSet[String] = environment.readTextFile(inPath)
    val res1: DataSet[String] = text.flatMap(_.split("\\s+"))
    val ans = res1.map((_, 1))
      .groupBy(0)
      .sum(1)
      .setParallelism(1)

    ans.writeAsCsv(outPath, "\n", "").setParallelism(1)

    environment.execute("hhaha")
  }
}
