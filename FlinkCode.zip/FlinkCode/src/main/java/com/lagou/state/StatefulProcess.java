package com.lagou.state;

import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.runtime.state.FunctionInitializationContext;
import org.apache.flink.runtime.state.FunctionSnapshotContext;
import org.apache.flink.streaming.api.checkpoint.CheckpointedFunction;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.util.Collector;

public class StatefulProcess extends KeyedProcessFunction<String, String, String> implements CheckpointedFunction {

    ValueState<Integer> processedInt;

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
    }

    @Override
    public void processElement(String value, Context ctx, Collector<String> out) throws Exception {
        try{
            Integer a =  Integer.parseInt(value);
            processedInt.update(a);
            out.collect(value);
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void snapshotState(FunctionSnapshotContext context) throws Exception {
        processedInt.clear();
    }

    @Override
    public void initializeState(FunctionInitializationContext context) throws Exception {
        processedInt = context.getKeyedStateStore().getState(new ValueStateDescriptor<>("processedInt", Integer.class));
        if(context.isRestored()){
            //Apply logic to restore the data
        }
    }
}
