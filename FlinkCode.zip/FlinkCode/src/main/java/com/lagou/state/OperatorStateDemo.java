package com.lagou.state;

import org.apache.flink.api.common.state.ListState;
import org.apache.flink.api.common.state.ListStateDescriptor;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.runtime.state.FunctionInitializationContext;
import org.apache.flink.runtime.state.FunctionSnapshotContext;
import org.apache.flink.streaming.api.checkpoint.CheckpointedFunction;
import org.apache.flink.streaming.api.functions.sink.SinkFunction;

import java.util.ArrayList;
import java.util.List;

/**
 * 1、在Flink中，做出OperatorState有两种方式：CheckpointedFunction 和 ListCheckPointed
 * 2、实现两个方法：initializeState和snapshotState
 *   initializeState：实例化状态
 *   snapshotState：在做checkPoint的时候会调用snapshotState
 * */
public class OperatorStateDemo implements SinkFunction<Tuple2<Long, Long>>, CheckpointedFunction {
    private ListState<Tuple2<Long, Long>> listState;
    private List<Tuple2<Long, Long>> bufferedElements;
    private int threshold;

    public OperatorStateDemo(int threshold) {
        System.out.println("构造函数");
        System.out.println(this.hashCode());
        this.threshold = threshold;
        this.bufferedElements = new ArrayList<>();
    }

    @Override
    public void initializeState(FunctionInitializationContext context) throws Exception {
        System.out.println("initializeState");
        System.out.println("1: " + this.hashCode());
        ListStateDescriptor<Tuple2<Long, Long>> descriptor = new ListStateDescriptor<>(
                "OperatorStateDemo", TypeInformation.of(new TypeHint<Tuple2<Long, Long>>() {}));
        listState = context.getOperatorStateStore().getListState(descriptor);

        // 给这个Buffer重新赋值，State会从最新的checkPoint自动恢复
        // 需要处理从 checkpoint/savepoint 恢复的情况
        // 通过 isRestored() 方法判断是否从之前的故障中恢复回来，如果该方法返回 true 则表示从故障中进行恢复，会执行接下来的恢复逻辑
        if (context.isRestored()) {
            for (Tuple2<Long, Long> ele : listState.get()) {
                bufferedElements.add(ele);
            }
            System.out.println("...context.isRestored()：True");
        }
    }

    /** 在做checkPoint的时候会调用snapshotState */
    @Override
    public void snapshotState(FunctionSnapshotContext context) throws Exception {
        //...checkPoint：snapshotState: [(9,9)]
        //...checkPoint：snapshotState: [(7,7)]
        //...checkPoint：snapshotState: [(1,1)]
        //...checkPoint：snapshotState: [(4,4), (6,6)]
        System.out.println("...checkPoint：snapshotState: " + listState.get().toString());
        this.listState.clear();
        for (Tuple2<Long, Long> ele : bufferedElements) {
            listState.add(ele);
        }
    }


    @Override
    public void invoke(Tuple2<Long, Long> value, Context context) throws Exception {
        bufferedElements.add(value);
        if (bufferedElements.size() == threshold) {
            bufferedElements.clear();
            System.out.println("Out: hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh");
        }
    }
}
