package com.lagou.state;

import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.util.Collector;

// 利用state求平均值
// 原始数据:(1,3)(1,5)(1,7)(1,4)(1,2)
/**输入：
 * 1,1
 * 1,1
 * 1,1
 * 1,1
 * 1,1
 * a,b
 * 1,1
 * */
public class StateTest1 {
    private SingleOutputStreamOperator<Tuple2<Long, Long>> flatMaped;

    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.enableCheckpointing(2000);
        env.setParallelism(4);

        DataStreamSource<String> source = env.socketTextStream("192.168.11.53", 7777);
        SingleOutputStreamOperator<Tuple2<Long, Long>> data = source.map(new MapFunction<String, Tuple2<Long, Long>>() {
            @Override
            public Tuple2<Long, Long> map(String value) throws Exception {
                String[] split = value.split(",");
                return new Tuple2<>(Long.valueOf(split[0]), Long.valueOf(split[1]));
            }
        });
//        DataStreamSource<Tuple2<Long, Long>> data = env.fromElements(
//                Tuple2.of(1L, 3L), Tuple2.of(1L, 5L), Tuple2.of(1L, 7L), Tuple2.of(1L, 4L), Tuple2.of(1L, 2L),
//                Tuple2.of(2L, 3L), Tuple2.of(2L, 5L), Tuple2.of(2L, 7L), Tuple2.of(2L, 4L), Tuple2.of(2L, 2L));
        KeyedStream<Tuple2<Long, Long>, Long> keyed = data.keyBy(value -> value.f0);
        //keyed.print();

        /** Keyed State：KeyedStream流上的每一个Key都对应一个State  */
        SingleOutputStreamOperator<Tuple2<Long, Long>> flatMaped = keyed.flatMap(new RichFlatMapFunction<Tuple2<Long, Long>, Tuple2<Long, Long>>() {
            private transient ValueState<Tuple2<Long, Long>> sum;

            @Override
            public void open(Configuration parameters) throws Exception {
                ValueStateDescriptor<Tuple2<Long, Long>> descriptor = new ValueStateDescriptor<>(
                        "average", TypeInformation.of(new TypeHint<Tuple2<Long, Long>>() {}), Tuple2.of(0L, 0L));
                //ValueStateDescriptor<Tuple2<Long, Long>> descriptor1 = new ValueStateDescriptor<>(
                //       "average", TypeInformation.of(new TypeHint<Tuple2<Long, Long>>() {}));
                sum = getRuntimeContext().getState(descriptor);
                super.open(parameters);
            }

            @Override
            public void flatMap(Tuple2<Long, Long> value, Collector<Tuple2<Long, Long>> out) throws Exception {
                //获取当前状态值
                Tuple2<Long, Long> currentSum = sum.value();
                //更新
                currentSum.f0 += 1;
                currentSum.f1 += value.f1;
                System.out.println("...currentSum:"+ currentSum);
                //更新状态值
                sum.update(currentSum);
                //如果count==2 清空状态值，重新计算
                if(currentSum.f0 == 2) {
                    out.collect(new Tuple2<>(value.f0, currentSum.f1 / currentSum.f0));
                    sum.clear();
                }
            }
        });

        //flatMaped.print();
        flatMaped.addSink(new OperatorStateDemo(3));

        env.execute();
    }
}
