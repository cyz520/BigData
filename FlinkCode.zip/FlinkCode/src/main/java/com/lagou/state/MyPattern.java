package com.lagou.state;

public class MyPattern {
    String firstAction;
    String secondAction;

    public MyPattern(){}

    public MyPattern(String firstAction, String secondAciotn) {
        this.firstAction = firstAction;
        this.secondAction = secondAciotn;
    }

    public String getFirstAction() {
        return firstAction;
    }

    public void setFirstAction(String firstAction) {
        this.firstAction = firstAction;
    }

    public String getSecondAction() {
        return secondAction;
    }

    public void setSecondAction(String secondAciotn) {
        this.secondAction = secondAciotn;
    }

    @Override
    public String toString() {
        return "MyPattern{" +
                "firstAction='" + firstAction + '\'' +
                ", secondAction='" + secondAction + '\'' +
                '}';
    }
}
class UserAction{
    Long userId;
    String userAction;

    public UserAction(){};

    public UserAction(Long userId, String action) {
        this.userId = userId;
        this.userAction = action;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUserAction() {
        return userAction;
    }

    public void setUserAction(String userAction) {
        this.userAction = userAction;
    }
}