package com.lagou.cep;

public class PayEvent {
    private long Id;
    private String name;
    private long ts;

    public PayEvent(long ID, String name, long ts) {
        this.Id = ID;
        this.name = name;
        this.ts = ts;
    }

    public long getId() {
        return Id;
    }

    public void setID(long ID) {
        this.Id = ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getTs() {
        return ts;
    }

    public void setTs(long ts) {
        this.ts = ts;
    }

    @Override
    public String toString() {
        return "PayEvent{" +
                "ID=" + Id +
                ", name='" + name + '\'' +
                ", ts=" + ts +
                '}';
    }
}
