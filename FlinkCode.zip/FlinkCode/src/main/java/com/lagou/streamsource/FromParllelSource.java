package com.lagou.streamsource;

import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

/**
 * 输出：
 * --8--
 * 4> 0
 * 8> 0
 * 5> 0
 * 6> 0
 * 2> 0
 * 1> 0
 * 7> 0
 * 3> 0
 * 4> 1
 * 1> 1
 * 2> 1
 * 6> 1
 * 5> 1
 * 8> 1
 * 3> 1
 * 7> 1
 * 5> 2
 * 7> 2
 * 3> 2
 * 1> 2
 * 8> 2
 * 4> 2
 * 2> 2
 * 6> 2
 *
 * 并行度为：8
 * */
public class FromParllelSource {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        DataStreamSource<String> data = env.addSource(new ParalleSource());
        System.out.println("--" + data.getParallelism() + "--");
        data.print();
        env.execute();
    }
}
