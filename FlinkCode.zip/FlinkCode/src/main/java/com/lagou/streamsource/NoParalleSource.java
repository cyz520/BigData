package com.lagou.streamsource;

import org.apache.flink.streaming.api.functions.source.SourceFunction;

/**
 * 并行度为1
 * */
public class NoParalleSource implements SourceFunction<String> {
    private Long count = 0L;
    private boolean isRunning = true;

    public void run(SourceContext<String> ctx) throws Exception {
        while (isRunning) {
            count++;
            ctx.collect(String.valueOf(count));
            Thread.sleep(1000);
        }
    }

    public void cancel() {
        isRunning = false;
    }
}
