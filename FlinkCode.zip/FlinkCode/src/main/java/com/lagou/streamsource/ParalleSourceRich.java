package com.lagou.streamsource;

import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;

/**
 * 有并行度：方式二
 * */
public class ParalleSourceRich extends RichParallelSourceFunction<String> {
    long count = 0;
    boolean isRunning = true;

    @Override
    public void run(SourceContext<String> ctx) throws Exception {
        while(isRunning) {
            ctx.collect(String.valueOf(count));
            count ++;
            Thread.sleep(1000);
        }
    }

    @Override
    public void cancel() {
        isRunning = false;
    }
}
