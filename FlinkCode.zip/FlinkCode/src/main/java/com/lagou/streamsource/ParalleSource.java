package com.lagou.streamsource;

import org.apache.flink.streaming.api.functions.source.ParallelSourceFunction;

/**
 * 有并行度：方式一
 * */
/**
 * SourceFunction.java
 * Sources that implement {@link org.apache.flink.streaming.api.checkpoint.CheckpointedFunction}
 must lock on the checkpoint lock (using a synchronized block) before updating internal state and emitting elements,
 to make both an atomic operation*/
public class ParalleSource implements ParallelSourceFunction<String> {
    private long count = 0;
    private boolean isRunning = true;

    /**
     * Kafka这里的run就不是这么简单了。
     * 它会去读取当前sub Task的编号，然后去读对应的Topic的分区数据，所以数据是只处理一次
     * */
    @Override
    public void run(SourceContext<String> ctx) throws Exception {
        while(isRunning) {
            // SourceFunction.java
            // this synchronized block ensures that state checkpointing,
            // internal state updates and emission of elements are an atomic operation
            synchronized (ctx.getCheckpointLock()) {
                ctx.collect(String.valueOf(count));
                count++;
                Thread.sleep(1000);
            }
        }
    }
    @Override
    public void cancel() {
        isRunning = false;
    }
}
