package com.lagou.streamsource;

import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

/**
 * 输出：
 * 7> 2
 * 8> 3
 * 1> 4
 * 2> 5
 * 3> 6
 * 4> 7
 * 5> 8
 * 6> 9
 * 7> 10
 * 8> 11
 * 1> 12
 * 2> 13
 * 3> 14
 *
 * NoParalleSource的并行度为1
 *
 * 本地模式运行，把我机器的Core数当做Slot，因此 > 括号前面的数字代表Slot的编号
 *
 * 轮询的方式发送这 1 个SubTask
 * */
public class FromNoParalleSource {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        DataStreamSource<String> data = env.addSource(new NoParalleSource());
        System.out.println("--" + data.getParallelism() + "--");
        data.print();
        env.execute();
    }
}