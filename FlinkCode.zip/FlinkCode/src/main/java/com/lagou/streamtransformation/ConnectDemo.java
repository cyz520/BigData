package com.lagou.streamtransformation;

import org.apache.flink.streaming.api.datastream.ConnectedStreams;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.co.CoMapFunction;
import org.apache.flink.streaming.api.functions.source.ParallelSourceFunction;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;

/**
 * 输出：
 * 6> 0
 * 5> 0
 * 3> 0 from Rich
 * 7> 0
 * 1> 0
 * 3> 0
 * 7> 0 from Rich
 * 1> 0 from Rich
 * 4> 0
 * 2> 0
 * 8> 0
 * 4> 0 from Rich
 * 5> 0 from Rich
 * 6> 0 from Rich
 * 2> 0 from Rich
 * 8> 0 from Rich
 * 7> 1
 * 4> 1
 * 5> 1
 * 6> 1
 * 5> 1 from Rich
 * 3> 1 from Rich
 * 1> 1
 * 8> 1
 * 7> 1 from Rich
 * 6> 1 from Rich
 * 2> 1
 * 1> 1 from Rich
 * 3> 1
 * 4> 1 from Rich
 * 2> 1 from Rich
 * 8> 1 from Rich
 *
 * */
public class ConnectDemo {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStreamSource<String> data1 = env.addSource(new ParalleSource());
        DataStreamSource<String> data2 = env.addSource(new ParalleSourceRich());

        ConnectedStreams<String, String> connected = data1.connect(data2);
        connected.map(new CoMapFunction<String, String, String>() {
            @Override
            public String map1(String value) throws Exception {
                return value;
            }

            @Override
            public String map2(String value) throws Exception {
                return value;
            }
        }).print();

        env.execute();
    }
}

class ParalleSource implements ParallelSourceFunction<String> {
    private long count = 0;
    private boolean isRunning = true;

    @Override
    public void run(SourceContext<String> ctx) throws Exception {
        while(isRunning) {
            ctx.collect(String.valueOf(count));
            count ++;
            Thread.sleep(1000);
        }
    }
    @Override
    public void cancel() {
        isRunning = false;
    }
}

class ParalleSourceRich extends RichParallelSourceFunction<String> {
    long count = 0;
    boolean isRunning = true;

    @Override
    public void run(SourceContext<String> ctx) throws Exception {
        while(isRunning) {
            ctx.collect(String.valueOf(count) + " from Rich");
            count ++;
            Thread.sleep(1000);
        }
    }

    @Override
    public void cancel() {
        isRunning = false;
    }
}