package com.lagou.table;

import org.apache.avro.data.Json;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.table.api.DataTypes;
import org.apache.flink.table.api.EnvironmentSettings;
import org.apache.flink.table.api.Table;
import org.apache.flink.table.api.bridge.java.StreamTableEnvironment;
import org.apache.flink.table.descriptors.*;
import org.apache.flink.types.Row;

public class FromKafka {
    public static void main(String[] args) throws Exception {
        //Flink执行环境env
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        //用env，做出Table环境tEnv
        EnvironmentSettings settings = EnvironmentSettings.newInstance()
                .useBlinkPlanner()
                .inStreamingMode()
//                .inBatchMode()
                .withBuiltInCatalogName("cyz_catalog")
                .withBuiltInDatabaseName("cyz_database")
                .build();
        StreamTableEnvironment tEnv = StreamTableEnvironment.create(env, settings);

        ConnectTableDescriptor descriptor = tEnv.connect(
                new Kafka()
                    .version("universal")
                    .topic("animal")
                    .startFromGroupOffsets()
                    .property("bootstrap.servers", "hdp-2:9092"))
                .withFormat(new Csv())
                .withSchema(
                    new Schema()
                        .field("rowtime", DataTypes.TIMESTAMP(3))
                        .rowtime(new Rowtime()
                            .timestampsFromField("rowtime")
                            .watermarksPeriodicBounded(60000))
                        .field("user", DataTypes.BIGINT())
                        .field("message", DataTypes.STRING())
                );

        descriptor.createTemporaryTable("MyUserTable");
        Table table1 = tEnv.sqlQuery("select * from MyUserTable");
        DataStream<Tuple2<Boolean, Row>> tuple2DataStream = tEnv.toRetractStream(table1, Row.class);
        tuple2DataStream.print();

        env.execute();
    }
}
