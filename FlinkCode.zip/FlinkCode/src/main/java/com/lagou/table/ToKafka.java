package com.lagou.table;

import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.table.api.DataTypes;
import org.apache.flink.table.api.EnvironmentSettings;
import org.apache.flink.table.api.Table;
import org.apache.flink.table.api.bridge.java.StreamTableEnvironment;
import org.apache.flink.table.descriptors.ConnectTableDescriptor;
import org.apache.flink.table.descriptors.Csv;
import org.apache.flink.table.descriptors.Kafka;
import org.apache.flink.table.descriptors.Schema;

import static org.apache.flink.table.api.Expressions.$;

public class ToKafka {
    public static void main(String[] args) {
        //Flink执行环境env
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        //用env，做出Table环境tEnv
        EnvironmentSettings settings = EnvironmentSettings.newInstance()
                .useBlinkPlanner()
                .inStreamingMode()
//                .inBatchMode()
                .withBuiltInCatalogName("cyz_catalog")
                .withBuiltInDatabaseName("cyz_database")
                .build();
        StreamTableEnvironment tEnv = StreamTableEnvironment.create(env, settings);

        //往kafka上输出表
        DataStreamSource<String> data = env.addSource(new SourceFunction<String>() {
            @Override
            public void run(SourceContext<String> ctx) throws Exception {
                int num = 0;
                while (true) {
                    num++;
                    ctx.collect("name" + num);
                    Thread.sleep(1000);
                }
            }
            @Override
            public void cancel() {}
        });

        Table name = tEnv.fromDataStream(data, $("name"));
        ConnectTableDescriptor descriptor = tEnv.connect(
                new Kafka()
                        .version("universal")
                        .topic("animal")
                        .property("bootstrap.servers", "hdp-2:9092"))
                .withFormat(new Csv())
                .withSchema(
                        new Schema().field("message", DataTypes.STRING())
                );
        descriptor.createTemporaryTable("MyUserTable");

        name.executeInsert("MyUserTable");
    }
}
