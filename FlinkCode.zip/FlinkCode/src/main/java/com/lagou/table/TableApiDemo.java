package com.lagou.table;

import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.table.api.EnvironmentSettings;
import org.apache.flink.table.api.Table;
import org.apache.flink.table.api.bridge.java.StreamTableEnvironment;
import org.apache.flink.types.Row;
import static org.apache.flink.table.api.Expressions.$;

/**
 * 打包到集群中运行，把这个注释掉再打包
*  <dependency>
*    <groupId>org.apache.flink</groupId>
*    <artifactId>flink-table-planner-blink_2.12</artifactId>
*    <version>1.11.1</version>
*  </dependency>
 * */
public class TableApiDemo {
    public static void main(String[] args) throws Exception {
        //Flink执行环境env
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(1);
        //用env，做出Table环境tEnv
        StreamTableEnvironment tEnv = StreamTableEnvironment.create(env);
//        EnvironmentSettings settings = EnvironmentSettings.newInstance()
//                .useBlinkPlanner()
//                .inStreamingMode()
////                .inBatchMode()
//                .withBuiltInCatalogName("cyz_catalog")
//                .withBuiltInDatabaseName("cyz_database")
//                .build();
//        StreamTableEnvironment tEnv = StreamTableEnvironment.create(env, settings);

        //获取流式数据源
        DataStreamSource<Tuple2<String, Integer>> data = env.addSource(new SourceFunction<Tuple2<String, Integer>>() {
           @Override
           public void run(SourceContext<Tuple2<String, Integer>> ctx) throws Exception {
               int count = 0;
               while (true) {
                   ctx.collect(new Tuple2<>(String.valueOf(count), count));
                   count++;
                   Thread.sleep(1000);
               }
           }
           @Override
           public void cancel() {}
        });
        SingleOutputStreamOperator<Tuple2<String, Integer>> map = data.map(new MapFunction<Tuple2<String, Integer>, Tuple2<String, Integer>>() {
            @Override
            public Tuple2<String, Integer> map(Tuple2<String, Integer> value) throws Exception {
                return new Tuple2<>(value.f0, value.f1 + 10000);
            }
        });

        map.print();/** 第一个JobGraph */

        //将流式数据源做成Table
        Table table = tEnv.fromDataStream(map, $("name"), $("age"));
        //对Table中的数据做查询
        Table name = table.select($("name"), $("age")).where($("age").between(0, 7000000));

        //将处理结果输出到控制台
        DataStream<Tuple2<Boolean, Row>> result = tEnv.toRetractStream(name, Row.class);
        result.print();/** 第二个JobGraph */

        // SQL方式
        tEnv.createTemporaryView("tabCYZ", map, $("name"), $("age"));
        String s = "select * from tabCYZ";
        Table table1 = tEnv.sqlQuery(s);
        DataStream<Tuple2<Boolean, Row>> res = tEnv.toRetractStream(table1, Row.class);
        res.print();/** 第三个JobGraph */

        env.execute();
    }
}
