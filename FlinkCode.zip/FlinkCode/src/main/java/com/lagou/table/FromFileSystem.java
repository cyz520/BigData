package com.lagou.table;

import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.table.api.DataTypes;
import org.apache.flink.table.api.EnvironmentSettings;
import org.apache.flink.table.api.Table;
import org.apache.flink.table.api.bridge.java.StreamTableEnvironment;
import org.apache.flink.table.descriptors.Csv;
import org.apache.flink.table.descriptors.FileSystem;
import org.apache.flink.table.descriptors.Schema;
import org.apache.flink.types.Row;

public class FromFileSystem {
    public static void main(String[] args) throws Exception {
        //Flink执行环境env
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        //用env，做出Table环境tEnv
        EnvironmentSettings settings = EnvironmentSettings.newInstance()
                .useBlinkPlanner()
                .inStreamingMode()
//                .inBatchMode()
                .withBuiltInCatalogName("cyz_catalog")
                .withBuiltInDatabaseName("cyz_database")
                .build();
        StreamTableEnvironment tEnv = StreamTableEnvironment.create(env, settings);

        tEnv.connect(new FileSystem().path("src/main/resources/sensor.txt"))// 定义表数据来源，外部连接
                .withFormat(new Csv()) // 定义从外部系统读取数据之后的格式化方法
                .withSchema(new Schema()
                        .field("name", DataTypes.STRING())
                        .field("timestamp", DataTypes.BIGINT())
                        .field("temperature", DataTypes.DOUBLE())) // 定义表结构
                .createTemporaryTable("inputTable"); // 创建临时表

        String sql = "select * from inputTable";
        Table table = tEnv.sqlQuery(sql);
        DataStream<Tuple2<Boolean, Row>> res = tEnv.toRetractStream(table, Row.class);
        res.print();

        env.execute();
    }
}
