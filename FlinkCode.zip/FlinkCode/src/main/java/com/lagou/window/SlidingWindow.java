package com.lagou.window;

import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.tuple.Tuple;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.datastream.WindowedStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.windowing.WindowFunction;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.GlobalWindow;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;

import java.text.SimpleDateFormat;
import java.util.Random;

/**
 * 滑动窗口:窗口可重叠 * 1、基于时间驱动
 * 2、基于事件驱动
 */
public class SlidingWindow {
    public static void main(String[] args) {
        // 设置执行环境, 类似spark中初始化SparkContext
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(1);

        DataStreamSource<String> dataStreamSource = env.socketTextStream("192.168.11.53", 7777);
        SingleOutputStreamOperator<Tuple3<String, String, Integer>> mapStream = dataStreamSource.map(new MapFunction<String, Tuple3<String, String, Integer>>() {
            @Override
            public Tuple3<String, String, Integer> map(String value) throws Exception {
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
                long timeMillis = System.currentTimeMillis();
                String dateTime = format.format(timeMillis);

                int random = new Random().nextInt(10);

                return new Tuple3<>(value, dateTime, random);
            }
        });

        KeyedStream<Tuple3<String, String, Integer>, String> keyedStream = mapStream.keyBy(ele -> ele.f0);

        //基于时间驱动，每隔2s计算一下最近5s的数据
        WindowedStream<Tuple3<String, String, Integer>, String, TimeWindow> timeWindow = keyedStream.timeWindow(Time.seconds(5), Time.seconds(2));
        timeWindow.sum(2).print();
        timeWindow.apply(new MyTimeWindowFunction2()).print();

        //基于事件驱动，每隔2个事件，触发一次计算，本次窗口的大小为3，代表窗口里的每种事件最多为3个
        // WindowedStream<Tuple3<String, String, Integer>, String, GlobalWindow> countWindow = keyedStream.countWindow(3, 2);
        //countWindow.sum(2).print();

        try {
            env.execute();
        } catch (Exception e){
            e.printStackTrace();
        }
    }
}

class MyTimeWindowFunction2 implements WindowFunction<Tuple3<String, String, Integer>, String, String, TimeWindow> {
    @Override
    public void apply(String key, TimeWindow window, Iterable<Tuple3<String, String, Integer>> input, Collector<String> out) throws Exception {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        int sum = 0;
        for(Tuple3<String, String, Integer> tuple3 : input){
            sum += tuple3.f2;
            //sum++;
        }
        long start = window.getStart();
        long end = window.getEnd();

        out.collect("key:" + key + " value: " + sum +
                "| window_start :" + format.format(start) + "  window_end :" + format.format(end));
    }
}

class MyCountWindowFunction2 implements WindowFunction<Tuple3<String, String, Integer>, String, String, GlobalWindow> {
    @Override
    public void apply(String key, GlobalWindow window, Iterable<Tuple3<String, String, Integer>> input, Collector<String> out) throws Exception {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        int sum = 0;
        for (Tuple3<String, String, Integer> tuple3 : input){
            sum += tuple3.f2;
        }
        //无用的时间戳，默认值为: Long.MAX_VALUE,因为基于事件计数的情况下，不关心时间。
        long maxTimestamp = window.maxTimestamp();
        out.collect("key:" + key + " value: " + sum + " | " + format.format(maxTimestamp));
    }
}