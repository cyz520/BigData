package com.lagou.window;

import org.apache.commons.math3.fitting.leastsquares.EvaluationRmsChecker;
import org.apache.flink.api.common.eventtime.*;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.tuple.Tuple;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.AssignerWithPeriodicWatermarks;
import org.apache.flink.streaming.api.functions.windowing.WindowFunction;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;
import org.apache.flink.util.OutputTag;
import sun.nio.cs.StreamEncoder;
import javax.annotation.Nullable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;

/**
 * 输入：
01,1586489566000
01,1586489567000

01,1586489569000
01,1586489570000

01,1586489572000
01,1586489573000

01,1586489583000

01,1586489593000

01,952371745000
----------------
01 2020-04-10 11:32:46
01 2020-04-10 11:32:47

01 2020-04-10 11:32:49
01 2020-04-10 11:32:50

01 2020-04-10 11:32:52
01 2020-04-10 11:32:53

01,2020-04-10 11:33:03

01,2020-04-10 11:33:13

01,2000-03-07 03:42:25
 * */

public class WaterMarkDemo {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        //env.setParallelism(5);
        env.setParallelism(1);
        env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);
        //env.getConfig().setAutoWatermarkInterval(1000L);

        DataStreamSource<String> data = env.socketTextStream("192.168.11.53", 7777);
        SingleOutputStreamOperator<Tuple2<String, Long>> maped = data.map(new MapFunction<String, Tuple2<String, Long>>() {
            @Override
            public Tuple2<String, Long> map(String value) throws Exception {
                String[] split = value.split(",");
                return new Tuple2<>(split[0], Long.valueOf(split[1]));
            }
        });

        /** 1.11版本把旧版本的两个API接口合一了 */
        SingleOutputStreamOperator<Tuple2<String, Long>> watermarks = maped.assignTimestampsAndWatermarks(new WatermarkStrategy<Tuple2<String, Long>>() {
            @Override
            public WatermarkGenerator<Tuple2<String, Long>> createWatermarkGenerator(WatermarkGeneratorSupplier.Context context) {
                return new WatermarkGenerator<Tuple2<String, Long>>() {
                    Long currentMaxTimestamp = 0L;
                    final Long maxOutOfOrderness = 2000L;

                    @Override
                    public void onEvent(Tuple2<String, Long> event, long eventTimestamp, WatermarkOutput output) {
                        System.out.println("onEvent: " + event.f1 + " " + eventTimestamp);
                        currentMaxTimestamp = Math.max(currentMaxTimestamp, event.f1);
                    }

                    //周期性调用
                    @Override
                    public void onPeriodicEmit(WatermarkOutput output) {
                        System.out.println("....onPeriodicEmit....");
                        /**  WaterMark可以基于Event Time，或基于ProcessingTime 或者精心设计的方式 */
                        output.emitWatermark(new Watermark(currentMaxTimestamp - maxOutOfOrderness));
                        //output.emitWatermark(new Watermark(System.currentTimeMillis() - maxOutOfOrderness));
                    }
                };
            }
        }.withTimestampAssigner(new SerializableTimestampAssigner<Tuple2<String, Long>>() {
            @Override
            public long extractTimestamp(Tuple2<String, Long> element, long recordTimestamp) {
                System.out.println("extractTimestamp: " + recordTimestamp);
                return element.f1;
            }
        }));

//        SingleOutputStreamOperator<Tuple2<String, Long>> watermarks =
//            maped.assignTimestampsAndWatermarks(new AssignerWithPeriodicWatermarks<Tuple2<String, Long>>() {
//                Long currentMaxTimestamp = 0L;
//                final Long maxOutOfOrderness = 1000L;
//                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
//
//                @Override
//                public long extractTimestamp(Tuple2<String, Long> element, long recordTimestamp) {
//                    long eventTimestamp = element.f1;
//                    currentMaxTimestamp = Math.max(eventTimestamp, currentMaxTimestamp);
//                    System.out.println("key: " + element.f0 + "...eventTimestamp:[" + eventTimestamp + "|" + sdf.format(eventTimestamp));
//                    System.out.println("currentMaxTimestamp: " + currentMaxTimestamp + "..." + sdf.format(currentMaxTimestamp));
//                    System.out.println("watermark: " + getCurrentWatermark().getTimestamp() + "..." + sdf.format(getCurrentWatermark().getTimestamp()));
//                    return eventTimestamp;
//                }
//
//                @Nullable
//                @Override
//                public Watermark getCurrentWatermark() {
//                    /**  WaterMark可以基于Event Time，或基于ProcessingTime  */
//                    //System.out.println("--" + currentMaxTimestamp.toString());
//                    return new Watermark(currentMaxTimestamp - maxOutOfOrderness);
//                    //return new Watermark(System.currentTimeMillis() - maxOutOfOrderness);
//                }
//            });

        SingleOutputStreamOperator<String> res =
                watermarks
                .keyBy(0)
                .window(TumblingEventTimeWindows.of(Time.seconds(3)))
                .apply(new WindowFunction<Tuple2<String, Long>, String, Tuple, TimeWindow>() {
                   @Override
                   public void apply(Tuple tuple, TimeWindow window, Iterable<Tuple2<String, Long>> input, Collector<String> out) throws Exception {
                       String key = tuple.getField(0);
                       ArrayList<Long> list = new ArrayList<>();
                       Iterator<Tuple2<String, Long>> it = input.iterator();
                       while (it.hasNext()) {
                           Tuple2<String, Long> next = it.next();
                           list.add(next.f1);
                       }
                       Collections.sort(list);
                       SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
                       String result = key + "," + list.size()
                               + "," + sdf.format(list.get(0)) + "," + sdf.format(list.get(list.size() - 1))
                               + "," + sdf.format(window.getStart()) + "," + sdf.format(window.getEnd());
                       out.collect(result);
                   }
            });

        res.print();

        env.execute();
    }
}
