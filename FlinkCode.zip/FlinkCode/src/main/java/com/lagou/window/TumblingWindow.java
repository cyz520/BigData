package com.lagou.window;

import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.tuple.Tuple;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.datastream.WindowedStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.windowing.WindowFunction;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.GlobalWindow;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;

import java.text.SimpleDateFormat;
import java.util.Random;

/**
 * 滚动窗口:窗口不重叠 * 1、基于时间驱动
 * 2、基于事件驱动
 */
public class TumblingWindow {
    public static void main(String[] args) {
        //设置执行环境，类似spark中初始化sparkContext
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(1);

        // nc -lp 7777
        DataStreamSource<String> dataStreamSource = env.socketTextStream("192.168.11.53", 7777);
        SingleOutputStreamOperator<Tuple3<String, String, Integer>> mapStream = dataStreamSource.map(new MapFunction<String, Tuple3<String, String, Integer>>() {
            @Override
            public Tuple3<String, String, Integer> map(String value) throws Exception {
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
                long timeMillis = System.currentTimeMillis();
                String dateTime = format.format(timeMillis);

                int random = new Random().nextInt(10);

                return new Tuple3<>(value, dateTime, random);
            }
        });
        KeyedStream<Tuple3<String, String, Integer>, String> keyedStream = mapStream.keyBy(ele -> ele.f0);

        // 基于时间驱动，每隔10s划分一个窗口
        WindowedStream<Tuple3<String, String, Integer>, String, TimeWindow> timeWindow = keyedStream.timeWindow(Time.seconds(5));
        // apply是窗口的应用函数，即apply里的函数将应用在此窗口的数据上。
        timeWindow.apply(new MyTimeWindowFunction()).print();

        // 基于事件驱动, 每相隔3个事件(即三个相同key的数据), 划分一个窗口进行计算
        // WindowedStream<Tuple3<String, String, Integer>, String, GlobalWindow> countWindow = keyedStream.countWindow(3);
        // countWindow.apply(new MyCountWindowFunction()).print();

        try {
            // 转换算子都是lazy init的, 最后要显式调用 执行程序
            env.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

class MyTimeWindowFunction implements WindowFunction<Tuple3<String, String, Integer>, String, String, TimeWindow> {
    /**
     * 输入：1     1       2
     * key:1 value: 1| window_start :2021-03-15 00:15:40.000  window_end :2021-03-15 00:15:45.000 Test: (1,1)
     * key:1 value: 1| window_start :2021-03-15 00:16:00.000  window_end :2021-03-15 00:16:05.000 Test: (1,2)
     * key:2 value: 1| window_start :2021-03-15 00:16:10.000  window_end :2021-03-15 00:16:15.000 Test: (2,3)
     * */
    private Tuple2<String, Long> Test = new Tuple2<>("", 0L);

    // 看入参：String key, TimeWindow window 意味着所有的key+window共享这一个WindowFunction对象，因此Test也是共享
    // 根据Slot的原理，内存都是分割的，因此是单线程的，所以线程安全
    // https://dzone.com/articles/four-ways-to-optimize-your-flink-applications 第二点的优化介绍
    @Override
    public void apply(String key, TimeWindow window, Iterable<Tuple3<String, String, Integer>> input, Collector<String> out) throws Exception {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        int sum = 0;
        for(Tuple3<String, String, Integer> tuple3 : input){
            //sum += tuple3.f2;
            sum++;
        }
        long start = window.getStart();
        long end = window.getEnd();
        Test.f0 = key;
        Test.f1 += (long)sum;

        out.collect("key:" + key + " value: " + sum +
                "| window_start :" + format.format(start) + "  window_end :" + format.format(end) + " Test: " + Test);
    }
}

class MyCountWindowFunction implements WindowFunction<Tuple3<String, String, Integer>, String, String, GlobalWindow> {
    @Override
    public void apply(String key, GlobalWindow window, Iterable<Tuple3<String, String, Integer>> input, Collector<String> out) throws Exception {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        int sum = 0;
        for (Tuple3<String, String, Integer> tuple3 : input){
            sum += tuple3.f2;
        }
        //无用的时间戳，默认值为: Long.MAX_VALUE,因为基于事件计数的情况下，不关心时间。
        long maxTimestamp = window.maxTimestamp();
        out.collect("key:" + key + " value: " + sum + " | " + format.format(maxTimestamp));
    }
}
