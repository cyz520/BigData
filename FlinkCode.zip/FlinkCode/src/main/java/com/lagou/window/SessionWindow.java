package com.lagou.window;

import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.tuple.Tuple;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.datastream.WindowedStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.assigners.ProcessingTimeSessionWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import java.text.SimpleDateFormat;
import java.util.Random;

public class SessionWindow {
    public static void main(String[] args) {
        // 设置执行环境, 类似spark中初始化sparkContext
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(1);

        DataStreamSource<String> dataStreamSource = env.socketTextStream("192.168.11.53", 7777);
        SingleOutputStreamOperator<Tuple3<String, String, Integer>> mapStream = dataStreamSource.map(new MapFunction<String, Tuple3<String, String, Integer>>() {
            @Override
            public Tuple3<String, String, Integer> map(String value) throws Exception {
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
                long timeMillis = System.currentTimeMillis();
                String dateTime = format.format(timeMillis);

                int random = new Random().nextInt(10);

                return new Tuple3<>(value, dateTime, random);
            }
        });

        KeyedStream<Tuple3<String, String, Integer>, String> keyedStream = mapStream.keyBy(ele -> ele.f0);

        //如果连续5s内，没有数据进来，则会话窗口断开。
        WindowedStream<Tuple3<String, String, Integer>, String, TimeWindow> window =
                keyedStream.window(ProcessingTimeSessionWindows.withGap(Time.seconds(5)));
        window.sum(2).print();
        window.apply(new MyTimeWindowFunction()).print();

        try {
            env.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
