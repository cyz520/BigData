package com.lagou;

import org.apache.flink.api.java.DataSet;
import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.operators.AggregateOperator;
import org.apache.flink.api.java.operators.FlatMapOperator;
import org.apache.flink.api.java.operators.UnsortedGrouping;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.util.Collector;
import org.apache.flink.api.common.functions.FlatMapFunction;

public class A_1WordCountJavaBatch {
    public static void main(String[] args) throws Exception {
        // 输入路径和出入路径通过参数传入，约定第一个参数为输入路径，第二个参数为输出路径
        String inPath = "/Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/7-第六阶段/FlinkCode/src/main/resources/hello.txt";
        String outPath = "/Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/7-第六阶段/FlinkCode/src/main/resources/output";

        // 获取Flink批处理执行环境
        ExecutionEnvironment executionEnvironment = ExecutionEnvironment.getExecutionEnvironment();

        // 获取文件中内容
        DataSet<String> text = executionEnvironment.readTextFile(inPath);
        // 对数据进行处理
        FlatMapOperator<String, Tuple2<String, Integer>> res1 = text.flatMap(new LineSplitter()).setParallelism(2);
        UnsortedGrouping<Tuple2<String, Integer>> res2 = res1.groupBy(0);
        AggregateOperator<Tuple2<String, Integer>> res3 = res2.sum(1).setParallelism(4);

        res3.writeAsCsv(outPath,"\n"," ").setParallelism(1);

        // 触发执行程序
        executionEnvironment.execute("wordcount batch process");
    }

    static class LineSplitter implements FlatMapFunction<String, Tuple2<String,Integer>> {
        @Override
        public void flatMap(String line, Collector<Tuple2<String, Integer>> collector) throws Exception {
            for (String word:line.split("\\s+")) {
                collector.collect(new Tuple2<>(word, 1));
            }
        }
    }
}
