package com.lagou.state2;

import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;

import java.util.Properties;
import java.util.Random;

public class TestFlink {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);
        Random random = new Random();

        //ParameterTool configuration = ParameterTool.fromArgs(args);
        FlinkKafkaConsumer<String> kafkaConsumer010 = new FlinkKafkaConsumer<>
                ("test", new SimpleStringSchema(), getKafkaConsumerProperties("testing123"));
        DataStreamSource<String> srcStream = env.addSource(kafkaConsumer010);

        DataStream<String> outStream =  srcStream
                .map(row -> new KeyValue("testing" + random.nextInt(100000), row))
                .keyBy(row -> row.getKey())
                .process(new StatefulProcess()).name("stateful_process").uid("stateful_process")
                .keyBy(row -> row.getKey())
                .flatMap(new StatefulMapTest()).name("stateful_map_test").uid("stateful_map_test");

        outStream.print();

        env.execute("Test Job");
    }

    public static Properties getKafkaConsumerProperties(String groupId){
        Properties props = new Properties();
        props.setProperty("bootstrap.servers", "localhost:9092");
        props.setProperty("group.id", groupId);
        return props;
    }
}
