package cn.lagou.sparksql

import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}

object A_3_Demo3 {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Demo1")
      .master("local[*]")
      .getOrCreate()
    val sc = spark.sparkContext
    sc.setLogLevel("warn")

    import spark.implicits._
    import org.apache.spark.sql.functions._
    val df1 = spark.read
      .option("header", "true")
      .option("inferschema","true")
      .csv("file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/emp.dat")

    df1.show()
    // 取10行数据生成新的DataSet
    val df2 = df1.limit(10)
    df2.show()

    // randomSplit(与RDD类似，将DF、DS按给定参数分成多份)
    val df3: Array[Dataset[Row]] = df1.randomSplit(Array(0.5, 0.6, 0.7))
    println("******************************")
    df3(0).show
    df3(1).show
    df3(2).show

    spark.close()
  }
}
