package cn.lagou.sparksql

import org.apache.spark.sql.SparkSession

object A_1_Demo1 {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Demo1")
      .master("local[*]")
      .getOrCreate()
    val sc = spark.sparkContext

    import spark.implicits._
    import org.apache.spark.sql.functions._
    val arr = Array(("Jack", 28, 150), ("Tom", 10, 144))
    val rddToDF = sc.makeRDD(arr).toDF("name", "age", "height")
    rddToDF.orderBy(desc("age")).show()

    spark.close()
  }
}
