package cn.lagou.homework

// 实际是个问答题

// 点击日志文件(click.log)
// INFO 2019-09-01 00:29:53 requestURI:/click?app=1&p=1&adid=18005472&industry=469&adid=31
// INFO 2019-09-01 00:30:31 requestURI:/click?app=2&p=1&adid=18005472&industry=469&adid=31
// INFO 2019-09-01 00:31:03 requestURI:/click?app=1&p=1&adid=18005472&industry=469&adid=32
// INFO 2019-09-01 00:31:51 requestURI:/click?app=1&p=1&adid=18005472&industry=469&adid=33

// 曝光日志文件(imp.log)
// INFO 2019-09-01 00:29:53 requestURI:/imp?app=1&p=1&adid=18005472&industry=469&adid=31
// INFO 2019-09-01 00:29:53 requestURI:/imp?app=1&p=1&adid=18005472&industry=469&adid=31
// INFO 2019-09-01 00:29:53 requestURI:/imp?app=1&p=1&adid=18005472&industry=469&adid=34

// 1、数据抽取
// 点击日志 => (18005472, 1) id为 18005472 的广告被点击了一次
// 曝光日志 => (18005472, 1) id为 18005472 的广告被曝光了一次

// 2、汇总
// 点击日志 => (18005472, 1) id为 18005472 的广告被点击了一次 => reduceByKey => (adid1, count1) adid1被点击了count1次
// 曝光日志 => (18005472, 1) id为 18005472 的广告被曝光了一次 => reduceByKey => (adid1, count2) adid1被曝光了count2次

// 3、连接
// (adid1, count1) join (adid1, count2) => (adid1, count1, count2) => adid1被点击了count1次，曝光了count2次

// 分析：以上过程是一个最普通的过程，全程有 3 次 Shuffle
// 做以下修改可以只有 1 次 Shuffle
// 1、数据抽取
// 点击日志 => (18005472, (1, 0))
// 曝光日志 => (18005472, (0, 1))
// 2、汇总
// (18005472, (1, 0)) ... ... (18005472, (0, 1)) => reduceByKey

class HomeWork3_ad {

}