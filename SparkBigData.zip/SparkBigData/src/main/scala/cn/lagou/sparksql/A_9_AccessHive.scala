package cn.lagou.sparksql

import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

object A_9_AccessHive {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Demo1")
      .master("local[*]")
      .enableHiveSupport()
      // 设为true时，Spark使用与Hive相同的约定来编写Parquet数据
      .config("spark.sql.parquet.writeLegacyFormat", true)
      .getOrCreate()

    val sc = spark.sparkContext
    sc.setLogLevel("warn")

    spark.sql("show databases").show
    spark.sql("select * from ods.ods_trade_product_info").show

    val df: DataFrame = spark.table("ods.ods_trade_product_info")
    df.show()
    df.write
      .mode(SaveMode.Append)
      .saveAsTable("ods.ods_trade_product_info_back")
    spark.table("ods.ods_trade_product_info_back").show

    spark.close()
  }
}
