package cn.lagou.sparksql

import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

object A_5_InputOutputFileDemo {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("A_5_InputOutputFileDemo")
      .master("local[*]")
      .getOrCreate()
    val sc = spark.sparkContext
    sc.setLogLevel("warn")

    // parquet
    val df1: DataFrame = spark.read.load("file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/users.parquet")
    df1.createOrReplaceTempView("t1")
    df1.printSchema()
    println(df1.rdd.getNumPartitions)
    df1.show

    spark.sql(
      """
        |CREATE OR REPLACE TEMPORARY VIEW users
        |USING parquet
        |OPTIONS (path "file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/users.parquet")
        |""".stripMargin)
    spark.sql("select * from users").show

    df1.write
      .format("parquet")
      .mode("overwrite")
      .option("compression", "snappy")
      .save("file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/parquet")

    println("********************************************************************")

    // csv
    val df2 = spark.read.format("csv")
      .option("header", "true")
      .option("inferschema", "true")
      .load("file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/people1.csv")
    df2.printSchema()
    println(df2.rdd.getNumPartitions)
    df2.show

    spark.sql( """
                 |CREATE OR REPLACE TEMPORARY VIEW people
                 |USING csv
                 |options(path "file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/people1.csv",
                 |        header "true",
                 |        inferschema "true")
                 |""".stripMargin)
    spark.sql("select * from people")
      .coalesce(2)
      .write
      .format("csv")
      .mode("overwrite")
      .save("file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/csv")

    println("********************************************************************")

    // Json
    val df3 = spark.read.format("json")
      .load("file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/emp.json")
    df3.printSchema()

    spark.sql(
      """
        |CREATE OR REPLACE TEMPORARY VIEW emp
        | USING json
        | options(path "file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/emp.json")
        |""".stripMargin)
    spark.sql("SELECT * FROM emp").show()
    spark.sql("SELECT * FROM emp")
      .write
      .format("json")
      .mode("overwrite")
      .save("file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/json")

    println("********************************************************************")

    // JDBC
    val jdbcDF = spark.read.format("jdbc")
      .option("url", "jdbc:mysql://192.168.11.53:3306/ebiz?useSSL=false")
      .option("driver", "com.mysql.jdbc.Driver")
      .option("dbtable", "lagou_product_info")
      .option("user", "hive")
      .option("password", "12345678")
      .load()
    jdbcDF.show()

    //    SaveMode.ErrorIfExists(默认)。若表存在，则会直接报异常，数据不能存入数据库
    //    SaveMode.Append。若表存在，则追加在该表中;若该表不存在，则会先创建表，再插入数据
    //    SaveMode.Overwrite。先将已有的表及其数据全都删除，再重新创建该表，最后插入新的数据
    //    SaveMode.Ignore。若表不存在，则创建表并存入数据;若表存在，直接跳过数据的存储，不会报错
    jdbcDF.write
      .format("jdbc")
      .option("url", "jdbc:mysql://192.168.11.53:3306/ebiz?useSSL=false&characterEncoding=utf8")
      .option("user", "hive")
      .option("password", "12345678")
      .option("driver", "com.mysql.jdbc.Driver")
      .option("dbtable", "lagou_product_info_back")
      .mode(SaveMode.Append)
      .save

    spark.close()
  }
}
