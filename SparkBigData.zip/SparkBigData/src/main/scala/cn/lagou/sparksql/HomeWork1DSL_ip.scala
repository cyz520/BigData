package cn.lagou.homework

import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkConf

/**
 * **1、找到ip所属区域**
 *
 * http.log：用户访问网站所产生的日志。日志格式为：时间戳、IP地址、访问网址、访问数据、浏览器信息等
 *
 * ip.dat：ip段数据，记录着一些ip段范围对应的位置
 *
 * 文件位置：data/http.log、data/ip.dat
 *
 * ~~~
 * # http.log样例数据。格式：时间戳、IP地址、访问网址、访问数据、浏览器信息
 * 20090121000132095572000|125.213.100.123|show.51.com|/shoplist.php?phpfile=shoplist2.php&style=1&sex=137|Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Mozilla/4.0(Compatible Mozilla/4.0(Compatible-EmbeddedWB 14.59 http://bsalsa.com/ EmbeddedWB- 14.59  from: http://bsalsa.com/ )|http://show.51.com/main.php|
 *
 * # ip.dat样例数据
 * 122.228.96.0|122.228.96.255|2061787136|2061787391|亚洲|中国|浙江|温州||电信|330300|China|CN|120.672111|28.000575
 * ~~~
 *
 * 要求：将 http.log 文件中的 ip 转换为地址。如将 122.228.96.111 转为 温州，并统计各城市的总访问量
 * */
object HomeWork1DSL_ip {
  def main(args: Array[String]): Unit = {
    // 初始化
    val conf = new SparkConf()
      .setAppName(this.getClass.getCanonicalName)
      .setMaster("local[*]")
    val spark: SparkSession = SparkSession.builder()
      .config(conf)
      .getOrCreate()
    spark.sparkContext.setLogLevel("WARN")

    // 读数据，并解析。将ip地址转换为Long类型
    import spark.implicits._
    spark.read
      .option("delimiter", "|")
      .csv("data/http.log")
      .map(row => row.getString(1))
      .createOrReplaceTempView("t1")

    // 读数据，解析，收回来。最后变为广播变量
    val ipData: Array[(Long, Long, String)] = spark.read
      .option("delimiter", "|")
      .csv("data/ip.dat")
      .map(row => (row.getString(2).toLong, row.getString(3).toLong, row.getString(6)))
      .collect()
    val ipBC = spark.sparkContext.broadcast(ipData.sortBy(_._1))

    def ip2Long(ip: String): Long = {
      // scala的fold，初始值、函数
      ip.split("\\.")
        .map(_.toLong)
        .fold(0L) { (buffer, elem) =>
          // 左移8位等价于乘以256,然后加上elem
          buffer << 8 | elem
        }
    }

    // 给定ip地址，在ips中查找对应的城市名。使用二分查找算法
    def getCityName(ip: Long): String = {
      val ips: Array[(Long, Long, String)] = ipBC.value
      var start = 0
      var end = ips.length - 1
      var middle = 0

      while (start <= end) {
        middle = (start + end) / 2
        if ((ip >= ips(middle)._1) && (ip <= ips(middle)._2))
          return ips(middle)._3
        else if (ip < ips(middle)._1)
          end = middle - 1
        else
          start = middle + 1
      }
      "Unknown"
    }

    spark.udf.register("ip2Long", ip2Long _)
    spark.udf.register("getCityName", getCityName _)
    /**
     * 列的名称是value
     * */
    spark.sql(
      """
        |select getCityName(ip2Long(value)) as provice, count(1) as no
        |  from t1
        |group by getCityName(ip2Long(value))
        |""".stripMargin).show

    spark.close()
  }
}