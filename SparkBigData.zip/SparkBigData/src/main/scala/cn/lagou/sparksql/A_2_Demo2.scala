package cn.lagou.sparksql

import org.apache.spark.sql.{DataFrame, SparkSession}

object A_2_Demo2 {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("Demo1")
      .master("local[*]")
      .getOrCreate()
    val sc = spark.sparkContext
    sc.setLogLevel("warn")

    import spark.implicits._
    import org.apache.spark.sql.functions._

    val df1: DataFrame = spark.read.csv("file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/people1.csv")
    df1.printSchema()
    df1.show()
    val df2: DataFrame = spark.read.csv("file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/people2.csv")
    df2.printSchema()
    df2.show()

    // 指定参数
    // spark 2.3.0
    // 可以放一个String，也可以放一个之前学的schema对象
    val schema = "name string, age int, job string"
    val df3: DataFrame = spark.read
      .options(Map(("delimiter", ";"), ("header", "true")))
      .schema(schema)
      .csv("file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/people2.csv")
    df3.printSchema()
    df3.show

    // 自动类型推断
    val df4: DataFrame = spark.read
      .option("delimiter", ";")
      .option("header", "true")
      .option("inferschema", "true")
      .csv("file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/people2.csv")
    df4.printSchema()
    df4.show

    spark.close()
  }
}
