package cn.lagou.sparksql

import org.apache.spark.sql.{Row, SparkSession}

object A_6_UDF {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder()
      .appName(this.getClass.getCanonicalName.init)
      .master("local[*]")
      .getOrCreate()
    spark.sparkContext.setLogLevel("WARN")

    val data = List(("scala", "author1"), ("spark", "author2"),
      ("hadoop", "author3"), ("hive", "author4"),
      ("strom", "author5"), ("kafka", "author6"))
    val df = spark.createDataFrame(data).toDF("title", "author")
    df.createTempView("books")

    // 定义Scala函数并注册
    def lenCyz(bookTitle: String):Int = bookTitle.length
    spark.udf.register("lenCyz", lenCyz _)
    // UDF可以在select语句、where语句等多处使用
    spark.sql("select title, author, lenCyz(title) from books").show
    spark.sql("select title, author from books where lenCyz(title)>5").show

    // UDF可以在DataFrame、Dataset的API中使用
    import spark.implicits._
    df.filter("lenCyz(title)>5").show

    // 如果要在DSL语法中使用$符号包裹字符串表示一个Column，需要用udf方法来接收函数。这种函数无需注册
    import org.apache.spark.sql.functions._
//    val lenCyz22 = udf((bookTitle: String) => bookTitle.length)
//    val a:(String) => Int = (bookTitle: String) => bookTitle.length
//    val lenCyz22 = udf(a)
    val lenCyz22 = udf(lenCyz _)
    df.filter(lenCyz22($"title") > 5).show
    df.select($"title", $"author", lenCyz22($"title")).show

    // 不使用UDF
    df.map{case Row(title: String, author: String) => (title, author, title.length)}.show

    spark.stop()
  }
}
