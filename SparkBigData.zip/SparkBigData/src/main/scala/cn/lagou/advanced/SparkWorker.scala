package org.apache.spark.deploy

import java.text.SimpleDateFormat
import java.util.{Date, Locale}
import java.util.concurrent.TimeUnit
import org.apache.spark.{SecurityManager, SparkConf}
import org.apache.spark.rpc.{RpcAddress, RpcEnv, ThreadSafeRpcEndpoint}
import org.apache.spark.util.{ThreadUtils, Utils}

private class SparkWorker(
                           override val rpcEnv: RpcEnv,
                           cores: Int,
                           memory: Int,
                           masterRpcAddresses: Array[RpcAddress],
                           endpointName: String,
                           val conf: SparkConf,
                           val securityMgr: SecurityManager) extends ThreadSafeRpcEndpoint {
  println("SparkWorker 的主构造器 。。。。。")

  private val host = rpcEnv.address.host
  private val port = rpcEnv.address.port
  private val workerId = generateWorkerId()
  // 心跳间隔时间，15s一次心跳
  private val HEARTBEAT_MILLIS = 60 * 1000 / 4

  private val forwordMessageScheduler = ThreadUtils.newDaemonSingleThreadScheduledExecutor("fake worker-forward-message-scheduler")

  override def onStart(): Unit = {
    val info = "onStart: Starting Spark worker %s:%d with %d cores, %sMRAM".format(host, port, cores, memory)
    println(info)
    // 向每一个 Master 注册
    masterRpcAddresses.map { masterAddress =>
      val masterEndpoint = rpcEnv.setupEndpointRef(masterAddress, SparkMaster.ENDPOINT_NAME)
      masterEndpoint.send(TestAdd(100, 200))
      masterEndpoint.send(RegisterWorker(workerId, host, port, self, cores, memory, masterAddress))
    }
  }

  override def receive: PartialFunction[Any, Unit] = {
    // 收到注册信息的回复，然后发送心跳
    case RegisteredWorker(master, masterAddress) =>
      println(s"receive: RegisteredWorker: master=$master masterAddress=$masterAddress")
      // 定时器执行
      forwordMessageScheduler.scheduleAtFixedRate(new Runnable {
        override def run(): Unit = Utils.tryLogNonFatalError {
          // 发送心跳
          master.send(Heartbeat(workerId, self))
        }
      }, 0, HEARTBEAT_MILLIS, TimeUnit.MILLISECONDS)
    case _ =>
      println("Worker 接收到 Unknown Message")
  }

  private def createDateFormat = new SimpleDateFormat("yyyyMMddHHmmss", Locale.US)

  private def generateWorkerId(): String = { "worker-%s-%s-%d".format(createDateFormat.format(new Date), host, port) }
}

object SparkWorker {
  val SYSTEM_NAME = "CYZyuzhongWorker"
  val ENDPOINT_NAME = "Worker"

  def main(args: Array[String]): Unit = {
    val host = "localhost"
    val port = 8888
    val cores = 4
    val memory = 4096

    val conf = new SparkConf
    val systemName = SYSTEM_NAME
    val securityMgr = new SecurityManager(conf)
    val rpcEnv = RpcEnv.create(systemName, host, port, conf, securityMgr)
    // Master的地址："localhost", 9999 这是master的地址
    val masterAddresses = Array(RpcAddress("localhost", 9999))

    rpcEnv.setupEndpoint(ENDPOINT_NAME,
      new SparkWorker(rpcEnv, cores, memory, masterAddresses, ENDPOINT_NAME, conf, securityMgr))

    rpcEnv.awaitTermination()
  }
}
