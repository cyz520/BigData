package org.apache.spark.deploy

import org.apache.spark.{SecurityManager, SparkConf}
import org.apache.spark.rpc.{RpcAddress, RpcEndpointRef, RpcEnv, ThreadSafeRpcEndpoint}

case class TestAdd(x: Int, y: Int)
case class TestSub(x: Int, y: Int)
case class RegisterWorker(workerId: String, host: String, port: Int, worker: RpcEndpointRef, cores: Int, memory: Int, masterAddress: RpcAddress)
case class RegisteredWorker(master: RpcEndpointRef, masterAddress: RpcAddress)
case class Heartbeat(workerId: String, worker: RpcEndpointRef)

private class SparkMaster(
                           override val rpcEnv: RpcEnv,
                           address: RpcAddress,
                           val securityMgr: SecurityManager,
                           val conf: SparkConf) extends ThreadSafeRpcEndpoint {
  println("SparkMaster 主构造器运行。。。")

  override def onStart(): Unit = {
    println("onStart: fake Master is starting .....................")
  }

  override def receive: PartialFunction[Any, Unit] = {
    case TestAdd(i, j) => println(s"x=$i + y=$j = ${i + j}")
    case TestSub(i, j) => println(s"x=$i - y=$j = ${i - j}")
    // 接收注册消息，然后向Worker回复
    case RegisterWorker(workerId, host, port, workerRef, cores, memory, masterAddress) =>
      println(s"receive: RegisterWorker: workId=$workerId workAddress=$host:$port cores=$cores memory=$memory")
      workerRef.send(RegisteredWorker(self, masterAddress))
    case Heartbeat(workerId, worker) =>
      println(s"Heartbeat: 接收到${workerId}心跳, time=${System.currentTimeMillis()}")
    case _ =>
      println("Master 接收到 Unknown Message")
  }

  override def onConnected(remoteAddress: RpcAddress): Unit = {
    println(s"onConnected: $remoteAddress is connectedzzzzzzzz")
  }

  override def onDisconnected(remoteAddress: RpcAddress): Unit = {
    println(s"onDisconnected: $remoteAddress is Disconnectedzzzzzzzzzzzzz")
  }
}

object SparkMaster {
  val SYSTEM_NAME = "CYZyuzhongMaster"
  val ENDPOINT_NAME = "Master"
  def main(args: Array[String]): Unit = {
    val host = "localhost"
    val port = 9999

    val conf = new SparkConf
    val securityMgr = new SecurityManager(conf)
    val rpcEnv = RpcEnv.create(SYSTEM_NAME, host, port, conf, securityMgr)
    val masterEndpoint = rpcEnv.setupEndpoint(ENDPOINT_NAME, new SparkMaster(rpcEnv, rpcEnv.address, securityMgr, conf))

    masterEndpoint.send(TestAdd(1, 100))
    masterEndpoint.send(TestSub(1, 100))


    rpcEnv.awaitTermination()
  }
}
