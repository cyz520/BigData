package cn.lagou.advanced

import org.apache.spark.rdd.RDD
import org.apache.spark.{HashPartitioner, SparkConf, SparkContext}

/**
 * // 窄依赖
 * val rdd1 = sc.parallelize(1 to 10, 1)
 * val rdd2 = sc.parallelize(11 to 20, 1)
 * val rdd3 = rdd1.union(rdd2)
 * rdd3.dependencies.size
 * rdd3.dependencies
 * // 打印rdd1的数据
 * rdd3.dependencies(0).rdd.collect
 * // 打印rdd2的数据
 * rdd3.dependencies(1).rdd.collect
 * // 查看RDD的血缘关系
 * rdd1.toDebugString
 *
 * // 宽依赖
 * val random = new scala.util.Random
 * val arr = (1 to 100).map(idx => random.nextInt(100))
 * val rdd1 = sc.makeRDD(arr).map((_, 1))
 * val rdd2 = rdd1.reduceByKey(_+_)
 *
 * // 观察依赖
 * rdd2.dependencies
 * rdd2.dependencies(0).rdd.collect
 * rdd2.dependencies(0).rdd.dependencies(0).rdd.collect
 * */
object JoinDemo {
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setAppName(this.getClass.getCanonicalName.init).setMaster("local[*]")
    val sc = new SparkContext(conf)
    sc.setLogLevel("WARN")

    val random = scala.util.Random

    val col1 = Range(1, 50).map(idx => (random.nextInt(10), s"user$idx"))
    val col2 = Array((0, "BJ"), (1, "SH"), (2, "GZ"), (3, "SZ"), (4, "TJ"), (5, "CQ"), (6, "HZ"), (7, "NJ"), (8, "WH"), (0,"CD"))

    val rdd1: RDD[(Int, String)] = sc.makeRDD(col1)
    val rdd2: RDD[(Int, String)] = sc.makeRDD(col2)

    val rdd3: RDD[(Int, (String, String))] = rdd1.join(rdd2)
    println(rdd3.dependencies)

    val rdd4: RDD[(Int, (String, String))] = rdd1.partitionBy(new HashPartitioner(5))
      .join(rdd2.partitionBy(new HashPartitioner(5)))
    println(rdd4.dependencies)
    rdd3.collect()
    rdd4.collect()

    Thread.sleep(100000)

    sc.stop()
  }
}
