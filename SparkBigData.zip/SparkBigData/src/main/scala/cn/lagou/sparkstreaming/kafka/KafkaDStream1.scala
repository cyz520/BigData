package cn.lagou.sparkstreaming.kafka

import org.apache.kafka.clients.consumer.{ConsumerConfig, ConsumerRecord}
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.streaming.dstream.InputDStream
import org.apache.spark.streaming.kafka010.{ConsumerStrategies, KafkaUtils, LocationStrategies}

/**
 * LocationStrategies.PreferBrokers:如果 Executor 在 kafka 集群中的某些节点 上，可以使用这种策略。此时Executor 中的数据会来自当前broker节点
 * LocationStrategies.PreferConsistent:大多数情况下使用的策略，将Kafka分 区均匀的分布在Spark集群的 Executor上
 * LocationStrategies.PreferFixed:如果节点之间的分区有明显的分布不均，使 用这种策略。通过一个map指定将 topic 分区分布在哪些节点中
 * */
/**
 * ConsumerStrategies.Subscribe，用来订阅一组固定topic
 * ConsumerStrategies.SubscribePattern，使用正则来指定感兴趣的topic
 * ConsumerStrategies.Assign，指定固定分区的集合
 *
 * 这三种策略都有重载构造函数，允许指定特定分区的起始偏移量;使用 Subscribe 或 SubscribePattern 在运行时能实现分区自动发现。
 * */
object KafkaDStream1 {
  def main(args: Array[String]): Unit = {
    // 初始化
    Logger.getLogger("org").setLevel(Level.ERROR)
    val conf: SparkConf = new SparkConf()
      .setMaster("local[2]")
      .setAppName(this.getClass.getCanonicalName)
    val ssc = new StreamingContext(conf, Seconds(2))

    // 定义kafka相关参数
    val kafkaParams: Map[String, Object] = getKafkaConsumerParameters("mygroup01")
    val topics: Array[String] = Array("topicB")

    // 从 kafka 中获取数据
    val dstream: InputDStream[ConsumerRecord[String, String]] = KafkaUtils.createDirectStream(
      ssc, LocationStrategies.PreferConsistent, ConsumerStrategies.Subscribe[String, String](topics, kafkaParams)
    )

    // DStream输出
    dstream.foreachRDD{(rdd, time) =>
      if (!rdd.isEmpty()) {
        println(s"*********** rdd.count = ${rdd.count()}; time = $time ***********")
      }
    }

    ssc.start()
    ssc.awaitTermination()
  }

  def getKafkaConsumerParameters(groupId: String): Map[String, Object] = {
    Map[String, Object](
      ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG -> "192.168.11.51:9092,192.168.11.52:9092,192.168.11.53:9092",
      ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG -> classOf[StringDeserializer],
      ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG -> classOf[StringDeserializer],
      ConsumerConfig.GROUP_ID_CONFIG -> groupId,
      ConsumerConfig.AUTO_OFFSET_RESET_CONFIG -> "earliest",
      ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG -> (false: java.lang.Boolean)
    )
  }
}
