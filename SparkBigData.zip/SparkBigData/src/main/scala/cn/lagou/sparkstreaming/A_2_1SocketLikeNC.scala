package cn.lagou.sparkstreaming

import java.io.PrintWriter
import java.net.{ServerSocket, Socket}
import scala.util.Random

/**
 * NC : 像一个服务端
 * 用 ServerSocket 模拟 NC
 * */
object A_2_1SocketLikeNC {
  def main(args: Array[String]): Unit = {
    val words: Array[String] = "Hello World Hello Hadoop Hello spark kafka hive zookeeper hbase flume sqoop".split("\\s+")
    val n: Int = words.length
    val port: Int = 9999
    val random: Random = scala.util.Random

    val server = new ServerSocket(port)
    val socket: Socket = server.accept()
    println("有客户端成功连接到本地主机:" + socket.getInetAddress)

    while (true) {
      // 给客户端返回数据。因为Socket是BIO，阻塞式的。
      val out = new PrintWriter(socket.getOutputStream)
      out.println(words(random.nextInt(n)) + " "+ words(random.nextInt(n)))
      out.flush()
      Thread.sleep(100)
    }
  }
}
