package cn.lagou.sparkstreaming

import org.apache.spark.SparkConf
import org.apache.spark.streaming.dstream.{DStream, ReceiverInputDStream}
import org.apache.spark.streaming.{Seconds, State, StateSpec, StreamingContext}

object A_6_2StateTracker2 {
  def main(args: Array[String]) {
    val conf: SparkConf = new SparkConf()
      .setMaster("local[*]")
      .setAppName(this.getClass.getCanonicalName)
    val ssc = new StreamingContext(conf, Seconds(2))
    ssc.sparkContext.setLogLevel("ERROR")

    // 生产环境中应设置到HDFS
    ssc.checkpoint("file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/checkpoint/")
    val lines = ssc.socketTextStream("localhost", 9999)
    val words = lines.flatMap(_.split("\\s+"))
    val pairsDStream = words.map(x => (x, 1))

    // 函数返回的类型即为 mapWithState 的返回类型
    // (KeyType, Option[ValueType], State[StateType]) => MappedType
    def mappingFunction(key: String, one: Option[Int], state: State[Int]): (String, Int) = {
      // 计算value
      val sum: Int = one.getOrElse(0) + state.getOption.getOrElse(0)
      // 更新State，为了下次的数据是正确的
      state.update(sum)
      // 也是用于全局统计key的状态。如果没有数据输入，便不会返回之前的key的状态，有一点增量的感觉
      (key, sum)
    }

    val spec = StateSpec.function(mappingFunction _)
    val resultDStream: DStream[(String, Int)] = pairsDStream.mapWithState[Int, (String, Int)](spec)
    // 把所有的拿出来，就跟updateStateByKey类似
    // val resultDStream: DStream[(String, Int)] = pairsDStream.mapWithState[Int, (String, Int)](spec).stateSnapshots()
    resultDStream.cache()

    resultDStream.print()
    // 把DStream保存到文本文件中，一个分区一个文件。执行repartition(1)，变成一个文件
    // 一个批次生成一个目录
    val outputDir = "file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/output2/"
    resultDStream
      .repartition(1)
      .saveAsTextFiles(outputDir)

    ssc.start()
    ssc.awaitTermination()
  }
}
