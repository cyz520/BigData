package cn.lagou.sparkstreaming

import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.streaming.dstream.{ConstantInputDStream, DStream}
import org.apache.spark.streaming.{Seconds, StreamingContext}

object A_4_1BlackListFilter1 {
  def main(args: Array[String]) {
    // 初始化
    val conf = new SparkConf()
      .setAppName(this.getClass.getCanonicalName.init)
      .setMaster( "local[2]")
    val ssc = new StreamingContext(conf, Seconds(10))
    ssc.sparkContext.setLogLevel("WARN")

    // 黑名单数据
    val blackList = Array(("spark", true), ("scala", true))
    val blackListRDD = ssc.sparkContext.makeRDD(blackList)

    // 生成测试DStream。使用ConstantInputDStream
    val strArray: Array[String] = "spark java scala hadoop kafka hive hbase zookeeper"
      .split("\\s+")
      .zipWithIndex
      .map { case (word, idx) => s"$idx $word" }
    val rdd = ssc.sparkContext.makeRDD(strArray)
    val clickStream: ConstantInputDStream[String] = new ConstantInputDStream(ssc, rdd)

    val clickStreamFormatted: DStream[(String, String)] = clickStream.map(value => (value.split("\\s+")(1), value))
    // 流式数据的处理
    /** transform算子*/
    clickStreamFormatted.transform(clickRDD => {
      /**leftOuterJoin 是SparkCore的算子*/
      val joinedBlackListRDD = clickRDD.leftOuterJoin(blackListRDD)
      joinedBlackListRDD.filter { case (word, (streamingLine, flag)) =>
        if (flag.getOrElse(false)) false
        else true
      }.map { case (word, (streamingLine, flag)) => streamingLine}
    }).print()

    // 启动流式作业
    ssc.start()
    ssc.awaitTermination()
  }
}
