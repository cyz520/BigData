package cn.lagou.sparkstreaming

import java.io.PrintWriter
import java.net.{ServerSocket, Socket}

object A_5_1SocketLikeNCWithWindow {
  def main(args: Array[String]): Unit = {
    val port = 1521
    val ss = new ServerSocket(port)
    val socket: Socket = ss.accept()/**阻塞式的*/
    println("connect to host : " + socket.getInetAddress)

    var i = 0
    // 每秒发送1个数
    while(true) {
      i += 1
      val out = new PrintWriter(socket.getOutputStream)
      out.println(i)
      out.flush()
      Thread.sleep(1000)
    }
  }
}
