package cn.lagou.sparkstreaming

import org.apache.spark.SparkConf
import org.apache.spark.streaming.dstream.{DStream, ReceiverInputDStream}
import org.apache.spark.streaming.{Seconds, StreamingContext}

object A_5_3HotWordStats {
  def main(args: Array[String]): Unit = {
    val conf: SparkConf = new SparkConf()
      .setMaster("local[*]")
      .setAppName(this.getClass.getCanonicalName.init)
    val ssc = new StreamingContext(conf, Seconds(2))
    ssc.sparkContext.setLogLevel("ERROR")

    //设置检查点，检查点具有容错机制。生产环境中应设置到HDFS
    ssc.checkpoint("file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/checkpoint/")
    val lines = ssc.socketTextStream("localhost", 9999)
    val words = lines.flatMap(_.split("\\s+"))
    val pairs = words.map(x => (x, 1))

    // 通过reduceByKeyAndWindow算子, 每隔10秒统计最近20秒的词出现的次数
    // 后3个参数: 窗口时间长度、滑动窗口时间、分区
    val wordCounts1: DStream[(String, Int)] = pairs.reduceByKeyAndWindow(
      (a: Int, b: Int) => a + b, Seconds(20), Seconds(10), 2)
    wordCounts1.print

    /** 这里需要checkpoint的支持*/
    /** 这个比上面的不需要checkpoint的方式更加的高效*/
    /**
     * window1 = t1 + t2 + t3 + t4
     * window2 = window1 - t1 - t2 + t5 + t6
     * */
    val wordCounts2: DStream[(String, Int)] = pairs.reduceByKeyAndWindow(
      _ + _, _ - _, Seconds(20), Seconds(10), 2)
    wordCounts2.print

    ssc.start()
    ssc.awaitTermination()
  }
}
