package cn.lagou.sparkstreaming

import org.apache.spark.SparkConf
import org.apache.spark.streaming.dstream.{DStream, ReceiverInputDStream}
import org.apache.spark.streaming.{Seconds, StreamingContext}

object A_6_1StateTracker1 {
  def main(args: Array[String]) {
    val conf: SparkConf = new SparkConf()
      .setMaster("local[*]")
      .setAppName(this.getClass.getCanonicalName)
    val ssc = new StreamingContext(conf, Seconds(5))
    ssc.sparkContext.setLogLevel("ERROR")

    // 生产环境中应设置到HDFS
    ssc.checkpoint("file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/checkpoint/")
    val lines = ssc.socketTextStream("localhost", 9999)
    val words = lines.flatMap(_.split("\\s+"))
    val wordDstream = words.map(x => (x, 1))

    // 定义状态更新函数
    // 函数常量定义，返回类型是Some(Int)，表示的含义是最新状态
    // 函数的功能是将当前时间间隔内产生的Key的value集合，加到上一个状态中，得到最新状态
    val updateFunc = (currValues: Seq[Int], prevValueState: Option[Int]) => {
      //通过Spark内部的reduceByKey按key规约，然后这里传入某key当前批次的 Seq，再计算当前批次的总和
      val currentCount = currValues.sum
      // 已累加的值
      val previousCount = prevValueState.getOrElse(0)
      Some(currentCount + previousCount)
    }

    val stateDstream: DStream[(String, Int)] = wordDstream.updateStateByKey[Int](updateFunc)
    stateDstream.cache()

    stateDstream.print()
    // 把DStream保存到文本文件中，一个分区一个文件。执行repartition(1)，变成一个文件
    // 一个批次生成一个目录
    val outputDir = "file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/output1/"
    stateDstream
      .repartition(1)
      .saveAsTextFiles(outputDir)

    ssc.start()
    ssc.awaitTermination()
  }
}
