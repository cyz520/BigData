package cn.lagou.sparkstreaming

import org.apache.spark.SparkConf
import org.apache.spark.streaming.dstream.{DStream, ReceiverInputDStream}
import org.apache.spark.streaming.{Seconds, StreamingContext}

/**
 * 作业刚起来，结果不太好看，一会儿就OK了。
 * 因为刚开始窗口没有撑满。
 *  每一批：5s
 *  窗口长度：20s
 *  滑动长度：10s
 *  那么刚开始，窗口没有撑满，10s的窗口是空的，10s的窗口是2批数据
 *  null null [1] [2 3 4 5 6] 窗口函数执行
 *  [1] [2 3 4 5 6] [7 8 9 10 11] [12 13 14 15 16] 窗口函数执行
 *  [7 8 9 10 11] [12 13 14 15 16] [17 18 19 20] [21 22 23 24 25]窗口函数执行
 *  ......
 *
 *  总结：窗口函数几秒执行一次 <==> 滑动长度
 * */
object A_5_2WindowDemo {
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf()
      .setMaster("local[*]")
      .setAppName(this.getClass.getCanonicalName.init)
    // 每 5s 生成一个RDD(mini-batch)
    val ssc = new StreamingContext(conf, Seconds(5))
    ssc.sparkContext.setLogLevel("error")


    val lines: ReceiverInputDStream[String] = ssc.socketTextStream("localhost", 1521)
    lines.foreachRDD{ (rdd, time) =>
      println(s"rddID = ${rdd.id}; time = $time")
      rdd.foreach(value => println(value))
    }

    // 20s 窗口长度;10s 滑动间隔
    val res1: DStream[String] = lines.reduceByWindow(_ + " " + _, Seconds(20), Seconds(10))
    res1.print()

    val res2: DStream[String] = lines.window(Seconds(20), Seconds(10))
    res2.print()

    // 求窗口元素的和
    val res3: DStream[Int] = lines.map(_.toInt).reduceByWindow(_+_, Seconds(20), Seconds(10))
    res3.print()

    // 求窗口元素的和
    val res4 = res2.map(_.toInt).reduce(_+_)
    res4.print()

    ssc.start()
    ssc.awaitTermination()
  }
}
