package cn.lagou.sparkstreaming

import org.apache.log4j.{Level, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.streaming.dstream.{DStream, InputDStream}
import org.apache.spark.streaming.{Seconds, StreamingContext}

import scala.collection.mutable.Queue

object A_3_RDDQueueDStream {
  def main(args: Array[String]) {
    Logger.getLogger("org").setLevel(Level.WARN)
    val sparkConf = new SparkConf()
      .setAppName(this.getClass.getCanonicalName)
      .setMaster( "local[1]")
    // 每隔1秒对数据进行处理
    val ssc = new StreamingContext(sparkConf, Seconds(1))

    // [] 这个不是数组的意思，是泛型
    val rddQueue = new Queue[RDD[Int]]()
    val queueStream: InputDStream[Int] = ssc.queueStream(rddQueue)
    val mappedStream: DStream[(Int, Int)] = queueStream.map(r => (r % 10, 1))
    val reducedStream: DStream[(Int, Int)] = mappedStream.reduceByKey(_ + _)
    reducedStream.print()

    ssc.start()


    // 每秒产生一个RDD
    for (i <- 1 to 5){
      // 涉及到同时出队和入队操作，所以要做同步
      rddQueue.synchronized {
        val range = (1 to 100).map(_*i)
        rddQueue += ssc.sparkContext.makeRDD(range)
      }
      Thread.sleep(1000)
    }


    ssc.stop()
  }
}
