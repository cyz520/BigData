package cn.lagou.sparkstreaming

import java.net.ServerSocket
import java.io.DataOutputStream
import java.net.Socket

object A_2_2SocketLikeNC2 {
  def main(args: Array[String]): Unit = {
    val server = new ServerSocket(9999)
    println(s"Socket Server 已启动: ${server.getInetAddress}:${server.getLocalPort}")

    while (true) {
      // BIO是阻塞的，会卡在这里
      val socket = server.accept()
      println("成功连接到本地主机:" + socket.getInetAddress)
      new ServerThread(socket).start()
    }
  }
}

class ServerThread(sock: Socket) extends Thread {
  val words = "hello world hello spark hello word hello java hello hadoop hello kafka" .split("\\s+")
  val length = words.length

  override def run(): Unit = {
    val out = new DataOutputStream(sock.getOutputStream)
    val random = scala.util.Random
    while (true) {
      val (wordx, wordy) = (words(random.nextInt(length)), words(random.nextInt(length)))
      out.writeUTF(s"$wordx $wordy")
      Thread.sleep(100)
    }
  }
}
