package cn.lagou.graphX

import org.apache.spark.graphx.{Graph, GraphLoader, VertexRDD}
import org.apache.spark.{SparkConf, SparkContext}

object GraphXExample2 {
  def main(args: Array[String]): Unit = {
    val conf: SparkConf = new SparkConf()
      .setAppName(this.getClass.getCanonicalName)
      .setMaster("local[*]")
    val sc = new SparkContext(conf)
    sc.setLogLevel("warn")

    // 从数据文件中加载，生成图
    val graph: Graph[Int, Int] = GraphLoader.edgeListFile(sc, "file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/graph.dat")

    graph
      .vertices
      .foreach(println)

    graph
      .edges
      .foreach(println)

    // 生成连通图
    /**
     * (4,1)
     * (431250,1)
     * (6,1)
     * (2,1)
     * (45067,1)
     * (1,1)
     * (3,1)
     * (7,1)
     * (5,1)
     *
     * (10,9)
     * (11,9)
     * (9,9)
     * (9111,9)
     * 两个联通体，里面的值都是顶点ID。第二位是那个联通体中最小的顶点ID值。
     * */
    graph
      .connectedComponents()
      .vertices
      .sortBy(_._2)
      .foreach(println)

    sc.stop()
  }
}
