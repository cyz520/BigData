package cn.lagou.graphX

import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.graphx.{Edge, Graph, VertexId, VertexRDD}
import org.apache.spark.rdd.RDD

/**
 * 案例三:寻找相同的用户，合并信息
 *
 * 假设:
 *   假设有五个不同信息可以作为用户标识，分别为:1X、2X、3X、4X、5X（手机号、微信号、QQ号、手机串码、邮箱地址）
 *   每次可以选择使用若干为字段作为标识
 *   部分标识可能发生变化，如:17 => 13(手机号变化) 或 29 => 28（微信号变化）
 *
 * 根据以上规则，判断以下标识是否代表同一用户:
 *   11-21-32、12-22-33 (X)（两个用户，手机号、微信号、QQ号都不同）
 *   11-21-32、11-21-52 (OK)（两个用户，手机号和微信号相同）
 *   21-32、11-21-33 (OK)（两个用户，微信号相同）
 *   11-21-32、32-48 (OK)（两个用户，QQ号相同）
 *
 * 问题:在以下数据中，找到同一用户，合并相同用户的数据
 *   对于用户标识(id):合并后去重
 *   对于用户的信息:key相同，合并权重
 *
 * List(11L, 21L, 31L), List("kw$北京" -> 1.0, "kw$上海" -> 1.0, "area$中关村" -> 1.0)
 * List(21L, 32L, 41L), List("kw$上海" -> 1.0, "kw$天津" -> 1.0, "area$回龙观" -> 1.0)
 * List(41L), List("kw$天津" -> 1.0, "area$中关村" -> 1.0)
 *
 * List(12L, 22L, 33L), List("kw$大数据" -> 1.0, "kw$spark" -> 1.0, "area$西二旗" -> 1.0)
 * List(22L, 34L, 44L), List("kw$spark" -> 1.0, "area$五道口" -> 1.0)
 * List(33L, 53L), List("kw$hive" -> 1.0, "kw$spark" -> 1.0, "area$西 二旗" -> 1.0)
 * */
object GraphXExample3 {
  def main(args: Array[String]): Unit = {
    // 初始化
    val conf: SparkConf = new SparkConf().setAppName("GraphXDemo").setMaster("local")
    val sc = new SparkContext(conf)
    sc.setLogLevel("error")

    // 定义数据
    val dataRDD: RDD[(List[Long], List[(String, Double)])] = sc.makeRDD(List(
      (List(11L, 21L, 31L), List("kw$北京" -> 1.0, "kw$上海" -> 1.0, "area$中关村" -> 1.0)),
      (List(21L, 32L, 41L), List("kw$上海" -> 1.0, "kw$天津" -> 1.0, "area$回龙观" -> 1.0)),
      (List(41L), List("kw$天津" -> 1.0, "area$中关村" -> 1.0)),
      (List(12L, 22L, 33L), List("kw$大数据" -> 1.0, "kw$spark" -> 1.0, "area$西二旗" -> 1.0)),
      (List(22L, 34L, 44L), List("kw$spark" -> 1.0, "area$五道口" -> 1.0)),
      (List(33L, 53L), List("kw$hive" -> 1.0, "kw$spark" -> 1.0, "area$西二旗" -> 1.0))
    ))

    // 1 将标识信息中的每一个元素抽取出来，作为id
    // 备注1、这里使用了flatMap，将元素压平;
    // 备注2、这里丢掉了标签信息，因为这个RDD主要用于构造顶点、边，tags信息不用
    // 备注3、顶点、边的数据要求Long，这个程序修改后才能用在我们的程序中
    val dotRDD: RDD[(VertexId, VertexId)] = dataRDD.flatMap { case (allids, _) => allids.map(id => (id, allids.mkString.hashCode.toLong)) }
    // 2 定义顶点
    val vertexesRDD: RDD[(VertexId, String)] = dotRDD.map { case (id, _) => (id, "") }
    // 3 定义边(id: 单个的标识信息;ids: 全部的标识信息)
    val edgesRDD: RDD[Edge[Int]] = dotRDD.map { case (id, ids) => Edge(id, ids, 0) }
    // 4 生成图
    // 大的顶点在边中使用了，因此生成的图也会包含大的顶点
    val graph = Graph(vertexesRDD, edgesRDD)
    // 5 找到强连通体
    val connectRDD: VertexRDD[VertexId] = graph.connectedComponents().vertices


    // 6 定义中心点的数据
    val centerVertexRDD: RDD[(VertexId, (List[VertexId], List[(String, Double)]))] =
      dataRDD.map { case (allids, tags) => (allids.mkString.hashCode.toLong, (allids, tags)) }
    // 7 步骤5、6的数据做join，获取需要合并的数据
    val allInfoRDD = connectRDD.join(centerVertexRDD)
      .map { case (_, (id2, (allIds, tags))) => (id2, (allIds, tags)) }
    // 8 数据聚合(即将同一个用户的标识、标签放在一起)
    val mergeInfoRDD: RDD[(VertexId, (List[VertexId], List[(String, Double)]))] =
      allInfoRDD.reduceByKey { case ((buffer1, buffer2), (allIds, tags)) =>
        val newList1 = buffer1 ++ allIds
        val newList2 = buffer2 ++ tags
        (newList1, newList2)
    }

    // 9 数据合并(allIds:去重;tags:合并权重)
    val resultRDD: RDD[(List[VertexId], Map[String, Double])] =
      mergeInfoRDD.map { case (key, (allIds, tags)) =>
        val newIds = allIds.distinct
        // 按照key做聚合;然后对聚合得到的lst第二个元素做累加
        val newTags = tags.groupBy(x => x._1).mapValues(lst => lst.map(x => x._2).sum)
        (newIds, newTags)
    }

    resultRDD.foreach(println)


    sc.stop()
  }
}
