package cn.lagou.sparkcore

import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

object B_4_Broadcast {
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setMaster("local[*]").setAppName(this.getClass.getCanonicalName.init)
    val sc = new SparkContext(conf)

    // 设置本地文件切分大小。（默认的本地文件切块是32M，这里修改为128M。这个跟分区数有关）
    sc.hadoopConfiguration.setLong("fs.local.block.size", 128*1024*1024)

    // 数据合并:有大量的数据移动
    val productRDD: RDD[(String, String)] =
      sc.textFile("/Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/lagou_product_info.txt")
      .map {
        line =>
          val fields = line.split(";")
          (fields(0), line)
      }
    /**
     * 广播变量：会在Driver端通过collectAsMap收到Driver中，然后利用BT协议分发
     * */
    val productBC: Broadcast[collection.Map[String, String]] = sc.broadcast(productRDD.collectAsMap())

    val orderRDD: RDD[(String, String)] =
      sc.textFile("/Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/orderinfo.txt",8 )
      .map {
        line =>
          val fields = line.split(";")
          (fields(2), line)
      }

    // map端的join，利用广播变量，省去了Shuffle
    val resultRDD = orderRDD.map{
      case (pid, orderInfo) =>
        val productInfo = productBC.value
        (pid, (orderInfo, productInfo.getOrElse(pid, null)))
    }
    println(resultRDD.count())

    Thread.sleep(1000000)

    sc.stop()
  }
}
