package cn.lagou.sparkcore

import java.sql.{Connection, DriverManager, PreparedStatement}

import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

/**
 * 优化后的程序:
 *   使用 foreachPartition 保存数据，一个分区创建一个链接
 *   cache RDD
 * */
object A_9_SuperWordCount3 {
  private val stopWords = List("the", "a", "in", "and", "to", "of", "for", "is", "are", "on", "you", "can", "your", "as")
  private val punctuation = "[\\)\\.,:;'!\\?]"
  private val username = "hive"
  private val password = "12345678"
  private val url = "jdbc:mysql://192.168.11.53:3306/ebiz?useUnicode=true&characterEncoding=utf-8&useSSL=false"

  def main(args: Array[String]): Unit = {
    // 1、创建SparkContext
    val conf = new SparkConf().setAppName(this.getClass.getCanonicalName.init).setMaster("local[*]")
    val sc = new SparkContext(conf)
    sc.setLogLevel("WARN")

    // 2、生成RDD
    val lines: RDD[String] = sc.textFile("file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/swc.dat")

    // 3、RDD转换
    val result = lines.flatMap(_.split("\\s+"))
      .map(_.toLowerCase)
      .map(_.replaceAll(punctuation, ""))
      .filter(word => !stopWords.contains(word) && word.trim.length > 0)
      .map((_, 1))
      .reduceByKey(_+_)
      .sortBy(_._2, false)

    result.cache()

    // 4、结果输出
    result.foreach(println)
    result.saveAsTextFile("file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/wcoutput3")

    // 数据输出到 MySQL
    // result.foreachPartition 是Action算子
    result.foreachPartition(itor => saveAsMySQL(itor))

    // 5、关闭SparkContext
    sc.stop()
  }

  def saveAsMySQL(iter: Iterator[(String, Int)]): Unit = {
    var conn: Connection = null
    var stmt: PreparedStatement = null
    val sql = "insert into wordcount values (?, ?)"

    try{
      /**
       * 创建多个连接去插入数据，一个分区一个连接，连接数量降低，比较均衡
       * */
      conn = DriverManager.getConnection(url, username, password)
      stmt = conn.prepareStatement(sql)
      iter.map{ case (word, count) =>
        stmt.setString(1, word)
        stmt.setInt(2, count)
        stmt.executeUpdate()
      }
    } catch {
      case e: Exception => e.printStackTrace()
    } finally {
      if (stmt != null) stmt.close()
      if (conn != null) conn.close()
    }
  }
}
