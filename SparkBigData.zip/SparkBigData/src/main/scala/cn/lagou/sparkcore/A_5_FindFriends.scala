package cn.lagou.sparkcore

import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

/**
 * 100, 200 300 400 500 600
 * 200, 100 300 400
 * 300, 100 200 400 500
 * 400, 100 200 300
 * 500, 100 300
 * 600, 100
 *
 * 第一列表示用户。逗号后面表示该用户的好友
 * 要求:
 * 1、查找两两用户的共同好友
 * 2、最后的结果按前两个id号有序排序
 * */
object A_5_FindFriends {

  def main(args: Array[String]): Unit = {
    // 创建SparkContext
    val conf = new SparkConf().setAppName(this.getClass.getCanonicalName).setMaster("local[*]")
    val sc = new SparkContext(conf)
    sc.setLogLevel("WARN")

    val lines: RDD[String] = sc.textFile("file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/fields.dat")

    val friendsRDD: RDD[(String, Array[String])] = lines.map { line =>
      val fields: Array[String] = line.split(",")
      val userId = fields(0).trim
      val friends: Array[String] = fields(1).trim.split("\\s+")
      (userId, friends)
    }

    // 方法一：核心思想利用笛卡尔积求两两的好友，然后去除多余的数据
    /**
     * friends1.intersect(friends2).sorted.toBuffer ：intersect是scala中Array的API，交集
    */
    friendsRDD.cartesian(friendsRDD)
      .filter { case ((id1, _), (id2, _)) => id1 < id2 }
      .map{ case ((id1, friends1), (id2, friends2)) =>
        // ((id1, id2), friends1.toSet & friends2.toSet)
        ((id1, id2), friends1.intersect(friends2).sorted.toBuffer)
      }
      .sortByKey()
      .collect().foreach(println)


    // 方法二：消除笛卡尔积，更高效。
    /**
     * 100, 200 300 400 500 600   ：200和300的共同好友有100、 200和400的共同好友有100、 200和500的共同好友有100。。。。。。
     * 200, 100 300 400  ： 按照上面的思路
     *
     * combinations：scala中Array的语法API，表示组合，这个排列组合会选出所有包含元素不一样的组合，但不考虑顺序，对于 “abc”、“cba”，视为相同组合，参数 n 表示序列长度，就是几个字符为一组
     * .map{case (k, v) => (v.mkString(" & "), Set(k))} ：数组用来作为KEY的话，使用地址去算hashcode，不符合我的要求。因此把数组转为String，然后使用reduceByKey的时候才OK
     * reduceByKey(_ | _) :因为value是Set集合，| 的意思是：取并集的意思
     * */
    println("*****************************************************************")
    friendsRDD.flatMapValues(friends => friends.combinations(2))
      //.map(x => (x._2.mkString(" & "), Set(x._1)))
      .map{case (k, v) => (v.mkString(" & "), Set(k))}
      .reduceByKey(_ | _)
      .sortByKey()
      .collect().foreach(println)

    // 关闭SparkContext
    sc.stop()
  }
}
