package cn.lagou.sparkcore

import org.apache.spark.rdd.RDD
import org.apache.spark.{Partitioner, SparkConf, SparkContext}
import scala.collection.immutable

class MyPartitioner(n: Int) extends Partitioner{
  // 分区个数
  override def numPartitions: Int = n
  // 分区规则，去往哪个分区
  override def getPartition(key: Any): Int = {
    val k = key.toString.toInt
    k / 100
  }
}
/**
 * 实现自定义分区器按以下规则分区:
 * 分区0 < 100
 * 100 <= 分区1 < 200
 * 200 <= 分区2 < 300
 * 300 <= 分区3 < 400
 * ... ...
 * 900 <= 分区9 < 1000
 * */
object UserDefinedPartitioner {
  def main(args: Array[String]): Unit = {
    // 创建SparkContext
    val conf = new SparkConf().setAppName(this.getClass.getCanonicalName.init).setMaster("local[*]")
    val sc = new SparkContext(conf)
    sc.setLogLevel("WARN")

    // 业务逻辑
    val random = scala.util.Random
    val arr: immutable.IndexedSeq[Int] = (1 to 100).map(idx => random.nextInt(1000))
    val rdd1: RDD[(Int, Int)] = sc.makeRDD(arr).map((_, 1))
    rdd1.glom.collect.foreach(x => println(x.toBuffer))

    println("********************************************************************************")
    // partitionBy主动使用分区器
    val rdd2 = rdd1.partitionBy(new MyPartitioner(10))
    rdd2.glom.collect.foreach(x => println(x.toBuffer))

    // 关闭SparkContext
    sc.stop()
  }
}
