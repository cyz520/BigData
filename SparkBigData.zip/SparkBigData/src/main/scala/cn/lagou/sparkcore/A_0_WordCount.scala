package cn.lagou.sparkcore

import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

object A_0_WordCount {
  def main(args: Array[String]): Unit = {
    // 创建环境变量、设置本地模式(我的MAC就是一个Spark单机)、设置所要执行APP的名字
    val conf = new SparkConf().setMaster("local").setAppName("WordCount")
    // 连接Spark Standalone集群
    /* val conf = new SparkConf().setMaster("spark://192.168.11.51:7077")
      .setJars(Array("target/SparkBigData-1.0-SNAPSHOT.jar"))
      .setAppName("WordCount")*/
    val sc = new SparkContext(conf)

    // data/wc.dat ： 在IDEA上的文件 ,在没有添加core-site.xml文件的时候访问本地的文件
    // val lines: RDD[String] = sc.textFile("data/wc.dat")

    // HDFS文件
    // val lines: RDD[String] = sc.textFile("hdfs://192.168.11.51:9000/wcinput/wc.txt")

    // HDFS文件 同时增加core-site.xml文件，否则会认为是本地文件
    val lines: RDD[String] = sc.textFile("/wcinput/wc.txt")

    lines.flatMap(_.split(" ")).map((_, 1)).reduceByKey(_+_).collect().foreach(println)

    // 执行完毕暂停程序，留时间看web界面
    // Thread.sleep(10000000)
    sc.stop()
  }
}
