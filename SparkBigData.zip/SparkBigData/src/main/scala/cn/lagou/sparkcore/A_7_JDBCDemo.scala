package cn.lagou.sparkcore

import java.sql.{Connection, DriverManager, PreparedStatement}

object A_7_JDBCDemo {
  def main(args: Array[String]): Unit = {

    // 定义结果集
    val str = "hadoop spark java scala hbase hive sqoop hue tez atlas datax grinffin zkkafka"
    val result: Array[(String, Int)] = str.split("\\s+").zipWithIndex

    // 定义连接信息
    val username = "hive"
    val password = "12345678"
    val url = "jdbc:mysql://192.168.11.53:3306/ebiz?useUnicode=true&characterEncoding=utf-8&useSSL=false"
    var conn: Connection = null
    var stmt: PreparedStatement = null
    val sql = "insert into wordcount values (?, ?)"

    try{
      /**
       * 只创建一个连接去插入数据，这样的话，插入的较慢
       * */
      conn = DriverManager.getConnection(url, username, password)
      stmt = conn.prepareStatement(sql)
      result.foreach{ case (word, count) =>
        stmt.setString(1, word)
        stmt.setInt(2, count)
        stmt.executeUpdate()
      }
    } catch {
      case e: Exception => e.printStackTrace()
    } finally {
      if (stmt != null) stmt.close()
      if (conn != null) conn.close()
    }
  }
}
