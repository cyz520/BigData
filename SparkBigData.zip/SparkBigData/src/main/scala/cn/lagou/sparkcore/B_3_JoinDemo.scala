package cn.lagou.sparkcore

import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

object B_3_JoinDemo {
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setMaster("local[*]").setAppName(this.getClass.getCanonicalName.init)
    val sc = new SparkContext(conf)

    // 设置本地文件切分大小。（默认的本地文件切块是32M，这里修改为128M。这个跟分区数有关）
    sc.hadoopConfiguration.setLong("fs.local.block.size", 128*1024*1024)

    // map task:数据准备
    val productRDD: RDD[(String, String)] =
      sc.textFile("file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/lagou_product_info.txt")
        .map {
          line =>
            val fields = line.split(";")
            (fields(0), line)
      }
    val orderRDD: RDD[(String, String)] =
      sc.textFile("file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/orderinfo.txt",8 )
        .map {
          line =>
            val fields = line.split(";")
            (fields(2), line)
    }

    /**
     * join有shuffle操作
     */
    val resultRDD = productRDD.join(orderRDD)
    println(resultRDD.count())

    Thread.sleep(1000000)

    sc.stop()
  }
}
