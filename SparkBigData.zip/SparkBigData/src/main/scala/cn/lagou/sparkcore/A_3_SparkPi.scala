package cn.lagou.sparkcore

import org.apache.spark.{SparkConf, SparkContext}
import scala.math.random

object A_3_SparkPi {
  def main(args: Array[String]): Unit = {
    // 1、创建SparkContext
    val conf = new SparkConf().setAppName(this.getClass.getCanonicalName.init).setMaster("local[*]")
    val sc = new SparkContext(conf)
    sc.setLogLevel("WARN")

    // 2、生成RDD;RDD转换
    val slices = if (args.length > 0) args(0).toInt else 10
    val N = 10000

    val count = sc.makeRDD(1 to N, slices)
      .map(idx => {
        // random随机生成大于等于0小于1的数字。因为最后看的是到(0，0)的距离，因此正负号无所谓
        val (x, y) = (random, random)
        // 到(0,0)的距离
        if (x*x + y*y <= 1) 1 else 0
      }).reduce(_+_)

    // 3、结果输出
    println(s"Pi is roughly ${4.0 * count / N}")

    // 4、关闭SparkContext
    sc.stop()
  }
}
