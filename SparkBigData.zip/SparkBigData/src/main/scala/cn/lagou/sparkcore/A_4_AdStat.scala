package cn.lagou.sparkcore

import org.apache.spark.{SparkConf, SparkContext}

/** 需求: 1、统计每一个省份点击TOP3的广告ID
 2、统计每一个省份每一个小时的TOP3广告ID

 解答：大部分是聚合算子来解决的
 */
/**
 * 你可能会以为这个数据文件读取是执行一次，
 * 但是事实上是，执行2次。后面有手段进行优化
 * */
object A_4_AdStat {
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setAppName(this.getClass.getCanonicalName.init).setMaster("local[*]")
    val sc = new SparkContext(conf)
    sc.setLogLevel("WARN")

    val N = 3

    // 读文件。字段：时间、省份、城市、用户、广告
    val lines = sc.textFile("file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/advert.log")
    val rawRDD = lines.map(line => {
      val arr = line.split("\\s+")
      // 时间、省份、广告
      (arr(0), arr(1), arr(4))
    })

    /**
     * 这里的 groupByKey 虽然可以用其他算子替换，但是其他算子的实现方式其实就是 groupByKey 的实现方式，数据没法在 Shuffle 中再优化了
     * 因此 groupByKey 没有必要被其他算子替换。场景比较特殊。
     * */
    // 需求1:统计每个省份点击 TOP3 的广告ID
    rawRDD.map { case (_, province, adid) => ((province, adid), 1) }
      .reduceByKey(_ + _)
      .map { case ((province, adid), count) => (province, (adid, count)) }
      .groupByKey()
      .mapValues(_.toList.sortWith(_._2 > _._2).take(N))
      .foreach(println)

    // 需求2:统计每个省份每小时 TOP3 的广告ID
    rawRDD.map { case (time, province, adid) => ((getHour(time), province, adid), 1) }
      .reduceByKey(_ + _)
      .map { case ((hour, province, adid), count) => ((hour, province), (adid, count)) }
      .groupByKey()
      .mapValues(_.toList.sortWith(_._2 > _._2).take(N))
      .foreach(println)

    sc.stop()
  }

  def getHour(timelong: String): String = {
    // Joda 类具有不可变性，它们的实例无法被修改。(不可变类的一个优点就是它们是线程安全的)
    import org.joda.time.DateTime
    val datetime = new DateTime(timelong.toLong)
    datetime.getHourOfDay.toString
  }
}
