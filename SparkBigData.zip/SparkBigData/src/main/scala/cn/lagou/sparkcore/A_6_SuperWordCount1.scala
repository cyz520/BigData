package cn.lagou.sparkcore

import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}
/**
 * 要求:将单词全部转换为小写、去除标点符号(难)、去除停用词(难)、最后按照 count 值降序保存到文件，同时将全部结果保存到MySQL(难)
 * 标点符号和停用词可以自定义。停用词:语言中包含很多功能词。与其他词相比，功能词没有什么实际含义。
 * 最普遍的功能词是[限定词](the、a、an、that、those)，介词(on、in、to、from、over等)、代词、数量词等。
 * */
object A_6_SuperWordCount1 {

  private val stopWords = "in on to from by a an the is are were was i we you your he his some any of as can it each".split("\\s+")
  private val punctuation = "[\\)\\.,:;'!\\?]" //这是一个正则. replaceAll是去除所有匹配上的

  def main(args: Array[String]): Unit = {
    // 创建SparkContext
    val conf = new SparkConf().setAppName(this.getClass.getCanonicalName.init).setMaster("local[*]")
    val sc = new SparkContext(conf)
    sc.setLogLevel("WARN")

    // RDD转换
    // 换为小写，去除标点符号(难)，去除停用词(难)
    val lines: RDD[String] = sc.textFile("file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/swc.dat")
    lines.flatMap(_.split("\\s+"))
      .map(_.toLowerCase)
      .map(_.replaceAll(punctuation, ""))
      .filter(word => !stopWords.contains(word) && word.trim.length > 0)
      .map((_, 1))
      .reduceByKey(_+_)
      .sortBy(_._2, false)
      .collect.foreach(println)

    // 关闭SparkContext
    sc.stop()
  }
}
