package cn.lagou.sparkcore

import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

object A_1_ScalaWordCount {
  def main(args: Array[String]): Unit = {
    // 1、创建SparkContext
    // val conf = new SparkConf().setMaster("local[*]").setAppName("ScalaWordCount")
    val conf = new SparkConf().setAppName("ScalaWordCount") // 打包的时候就不加上 setMaster，到时候由 spark-submit 的参数控制
    val sc = new SparkContext(conf)
    sc.setLogLevel("WARN")

    // 2、读取文件(集群运行:输入参数)
    val lines: RDD[String] = sc.textFile(args(0)) // 由 spark-submit 的参数控制
    // val lines: RDD[String] = sc.textFile("file:////Users/chenyuzhong/Cyz-文件2/0-拉钩大数据/5-第四阶段/2-大数据正式班第四阶段模块二/SparkBigData/data/wc.dat")

    // 3、RDD转换
    val words: RDD[String] = lines.flatMap(line => line.split("\\s+")) // \\s+是正则，按照空格、Tab等等切分
    val wordsMap: RDD[(String, Int)] = words.map(x => (x, 1))
    val result: RDD[(String, Int)] = wordsMap.reduceByKey(_ + _)

    // 4、输出
    result.foreach(println)

    // 5、关闭SparkContext
    sc.stop()

    // 6、打包，使用spark-submit提交集群运行
    // spark-submit --master local[*] --class cn.lagou.sparkcore.ScalaWordCount /路径/original-LagouBigData-1.0-SNAPSHOT.jar /wcinput/*
    // spark-submit --master yarn --class cn.lagou.sparkcore.ScalaWordCount /路径/original-LagouBigData-1.0-SNAPSHOT.jar /wcinput/*
    // spark-submit --class cn.lagou.sparkcore.ScalaWordCount /路径/original-LagouBigData-1.0-SNAPSHOT.jar /wcinput/*
  }
}